<?php
    require "../koneksi.php";

    if (isset($_SESSION['nama'])) {
        $nama = $_SESSION['nama'];
    } else {
        // Handle the case where the session variable is not set
        $nama = "Guest"; // Or any other default value
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sidebar</title>
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <link rel="stylesheet" href="fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<style>
    body, h1, h2, h3, h4, h5 {
        font-family: "Poppins", sans-serif;
        font-weight: bold;
    }
    body {
        font-size: 20px;
    }
    .sidebar {
        height: 100%;
        width: 300px;
        position: fixed;
        z-index: 3;
        top: 0;
        left: 0;
        background-color: #A34343;
        overflow-x: hidden;
        padding-top: 20px;
        transition: 0.5s;
    }
    .sidebar .container {
        padding: 0px;
    }
    .sidebar h3 {
        padding: 50px;
        color: white;
    }
    .sidebar .bar-block {
        width: 100%;
    }
    .sidebar .bar-item {
        padding: 8px 16px;
        display: flex;
        color: white;
        text-decoration: none;
        align-items: center;
    }
    .sidebar .bar-item:hover {
        background-color: white;
        color: black;
    }
    .sidebar .icon {
        margin-right: 8px;
        justify-content: left;
    }
    .sidebar .text {
        flex: 2;
    }
    .sidebar .closebtn {
        position: absolute;
        top: 10px;
        right: 20px;
        font-size: 25px;
        color: white;
        display: none; /* Hide the close button by default */
    }
    ul.nav.justify-content-end {
        background-color: #FBF8DD; 
        padding: 10px 10px;
        position: fixed;
        z-index: 2;
        top: 0;
        width: 100%;
        display: flex;
        justify-content: space-between; /* Distribute space between the toggle and the rest */
        align-items: center; /* Center the items vertically */
    }
    .menu-toggle {
        font-size: 25px;
        margin-right: 20px;
        cursor: pointer;
        color: black;
        display: none; /* Hide the toggle button by default */
    }
    @media screen and (max-width: 768px) {
        .sidebar {
            width: 0;
            transition: 0.5s;
        }
        .sidebar.open {
            width: 300px;
        }
        .menu-toggle {
            display: block; /* Show the toggle button on small screens */
        }
        .sidebar .closebtn {
            display: block; /* Show the close button on small screens */
        }
    }
</style>
</head>
<body>
    <nav class="sidebar" id="mySidebar">
        <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
        <div class="container">
            <h3 class="padding"><b>E-Absensi</b></h3>
        </div>
        <div class="bar-block">
            <a href="mahasiswa_index.php" class="bar-item button hover-white">
                <i class="fas fa-sign-in-alt icon"></i> 
                <span class="text">Presensi</span>
            </a>
            <a href="rekap_absensi.php" class="bar-item button hover-white">
                <i class="far fa-folder-open icon"></i> 
                <span class="text">Riwayat Presensi</span> 
            </a>
            <a href="profile_mahasiswa.php" class="bar-item button hover-white">
                <i class="fas fa-user icon"></i> 
                <span class="text">Profile Mahasiswa</span>
            </a>
        </div>
    </nav>
    <ul class="nav justify-content-end">
        <li class="nav-item">
            <span class="menu-toggle" onclick="openNav()">&#9776;</span>
        </li>
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle text-dark no-decoration" href="#" role="button" id="navbarDropdown" aria-haspopup="true" aria-expanded="false" data-bs-toggle="dropdown">
                <i class="fas fa-user"></i> <?php echo $nama; ?>
            </a>
            <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                <a class="dropdown-item" href="../login.php">Logout</a>
            </div>
        </li>
    </ul>
<script>
    function openNav() {
        document.getElementById("mySidebar").classList.add("open");
    }

    function closeNav() {
        document.getElementById("mySidebar").classList.remove("open");
    }

    document.addEventListener("DOMContentLoaded", function () {
        var dropdownToggle = document.querySelector('.dropdown-toggle');
        var dropdownMenu = document.querySelector('.dropdown-menu');

        dropdownToggle.addEventListener('click', function () {
            dropdownMenu.classList.toggle('show');
        });
    });
</script>
<script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="fontawesome/js/all.min.js"></script>
</body>
</html>
