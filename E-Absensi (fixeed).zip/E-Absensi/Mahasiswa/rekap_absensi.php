<?php
    session_start();
    require "../koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <title>Riwayat Presensi Mahasiswa Magang</title>
    <style>
         /* CSS untuk mengatur tata letak teks di dalam tabel */
         .table {
            text-align: center; /*Menengahkan teks secara horizontal*/
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.20); 
            font-size: 0.9rem;
        }
        .table th,
        .table td {
            vertical-align: middle; /*Menengahkan teks secara vertikal*/
            border: 1px solid;
        }
        .table thead {
            background-color: #D1BB9E;
        }
        /* CSS untuk meletakkan tabel di tengah */
        .table-container {
            margin: 0 auto; /* Membuat margin otomatis di sisi kiri dan kanan */
            width: 95%; /* Sesuaikan dengan lebar yang diinginkan */
            display: block; /* Mengubah tata letak menjadi block agar margin otomatis bekerja */
        }
        /* CSS untuk container utama */
        .main {
            margin-left: 350px; /* Adjust according to the sidebar width */
            margin-top: 90px; /* Adjust according to the navbar height */
        }
        @media (max-width: 768px) {
            /* Adjusting sidebar and main content for mobile */
            .main {
                margin-left: 0;
                margin-top: 70px; /* Adjust according to the navbar height */
            }
            .table {
                font-size: 0.8rem; /* Adjust font size for mobile */
            }
        }
    </style>
</head>
<body>
    <!---sidebar--->
    <?php require "sidebar_mahasiswa.php"; ?>

    <!---page content--->
    <div class="main">
        <header class="container" style="padding-top:10px;">
            <h5><i class="far fa-folder"></i><b> Riwayat Presensi</b></h5>
        </header> 

        <div class="container-fluid">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="row p-3 align-items-center">
                    <div class="col-12 col-md-4">
                        <label for="tanggal_awal">Tanggal Awal</label>
                        <input type="date" name="tanggal_awal" id="tanggal_awal" class="form-control" placeholder="Tanggal Awal" aria-label="Tanggal Awal">
                    </div>
                    <div class="col-12 col-md-4">
                        <label for="tanggal_akhir">Tanggal Akhir</label>
                        <input type="date" name="tanggal_akhir" id="tanggal_akhir" class="form-control" placeholder="Tanggal Akhir" aria-label="Tanggal Akhir">
                    </div>
                    <div class="col-12 col-md-4">
                            <br>
                            <button class="btn btn-primary" type="submit" name="submit">Lihat Rekapan</button>
                    </div>
                </div>
            </form>
        </div>
        <?php
            if(isset($_POST['submit'])){
                $tanggal_awal = htmlspecialchars($_POST['tanggal_awal']);
                $tanggal_akhir = htmlspecialchars($_POST['tanggal_akhir']);
                $id_intern = $_SESSION['id_intern']; //Ambil id_intern dari sesi

                // Mengambil query dari absensi datang
                $query_absensi_datang = "SELECT tanggal, jam_datang, '' AS jam_pulang, keterangan, '' AS laporan, file 
                                         FROM absensi_datang 
                                         WHERE tanggal BETWEEN '$tanggal_awal' AND '$tanggal_akhir'
                                         AND id_intern = '$id_intern'"; // Menambahkan kondisi WHERE untuk id_intern

                // Mengambil query dari absensi pulang
                $query_absensi_pulang = "SELECT tanggal, '' AS jam_datang , jam_pulang, '' AS keterangan, laporan, '' AS file 
                                         FROM absensi_pulang 
                                         WHERE tanggal BETWEEN '$tanggal_awal' AND '$tanggal_akhir'
                                         AND id_intern = '$id_intern'"; // Menambahkan kondisi WHERE untuk id_intern

                // Menggabungkan kedua query dengan UNION
                $query_rekap_absensi = "SELECT tanggal, 
                                        CASE WHEN keterangan IN ('sakit', 'izin') THEN '' ELSE MAX(jam_datang) END AS jam_datang, 
                                        MAX(jam_pulang) AS jam_pulang, 
                                        MAX(keterangan) AS keterangan,
                                        MAX(laporan) AS laporan,
                                        MAX(file) AS file
                                        FROM (
                                            $query_absensi_datang
                                            UNION
                                            $query_absensi_pulang
                                        ) AS subquery
                                        GROUP BY tanggal";

                // Menjalankan query rekap absensi
                $result_rekap_absensi = mysqli_query($con, $query_rekap_absensi);

                // Memeriksa apakah query berhasil dijalankan
                if($result_rekap_absensi){
                    // Menampilkan tabel rekap absensi
                    echo '<div class="table-container">'; // Tambahkan div dengan kelas table-container
                    echo '<div class="table-responsive mt-3">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Jam Datang</th>
                                        <th>Jam Pulang</th>
                                        <th>Keterangan</th>
                                        <th>Laporan</th>
                                        <th>File</th>
                                    </tr>
                                </thead>
                                <tbody>';
                    // Menampilkan data rekap absensi
                    while($row = mysqli_fetch_assoc($result_rekap_absensi)){
                        echo '<tr>';
                        echo '<td>' . $row['tanggal'] . '</td>';
                        echo '<td>' . $row['jam_datang'] . '</td>'; // Kolom jam datang akan tetap ditampilkan, tapi bisa kosong
                        echo '<td>' . $row['jam_pulang'] . '</td>';
                        echo '<td>' . $row['keterangan'] . '</td>';
                        echo '<td>' . $row['laporan'] .'</td>';
                        
                        // Menambahkan kondisi untuk menampilkan tautan file jika ada file yang diunggah, tidak peduli dengan jenis keterangan absensi
                        if($row['file'] != ''){
                            // Tautan ke file yang dapat diunduh
                            echo '<td><a href="../uploads/' . $row['file'] . '" download><i class="far fa-file-pdf"></i></a></td>';
                        } else {
                            // Jika tidak ada file yang diunggah, tampilkan pesan tidak ada file
                            echo '<td>Tidak ada file</td>';
                        }
                        
                        echo '</tr>';
                    }
                    echo '</tbody></table></div></div>'; // Tutup div table-container
                } else {
                    echo 'Gagal melihat rekap absensi' . mysqli_error($con);
                }
            }
        ?>
    </div>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>
