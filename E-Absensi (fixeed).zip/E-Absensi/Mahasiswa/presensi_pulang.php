<?php
session_start();
require "../koneksi.php";

$query = mysqli_query($con, "SELECT * FROM absensi_pulang");
$data = mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Presensi Pulang Mahasiswa Magang</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <style>
        body, h1,h2,h3,h4 {
            font-size: 30px;
            font-family: "Poppins", sans-serif;
            font-weight: bold;
        }
        .card {
            width: 500px;
            height: 400px;
            background-color: #EEEEEE;
            border: 2px solid #31363F;
            margin: auto;
        }
        .alert-container {
            width: 100%; /* Sesuaikan lebar dengan lebar card */
            display: flex;
            justify-content: center;
        }
        .alert-custom {
            border: 1px solid transparent;
            border-radius: .25rem;
            padding: .75rem 1.25rem;
            margin-top: 1rem;
            width: calc(100% - 40rem); /* Lebar card dikurangi padding */
            margin: auto;
        }
        .alert-custom-danger {
            color: #ffff;
            background-color: #D71313;
            border-color: #ffeeba;
        }
    </style>
</head>
<body>
    <!---sidebar--> 
    <?php require "sidebar_mahasiswa.php"; ?>

    <!---page content--->
    <div class="main" style="margin-left:350px; margin-top:90px;">
        <header class="container" style="padding-top:10px;">
            <h5><i class="fas fa-user-clock"></i><b> Presensi Pulang</b></h5>
        </header> 

        <!--content-->
    <div class="card shadow mt-3" style="padding: 40px;">
        <form action="" method="post" enctype="multipart/form-data">
            <div class="mt-3">
                <label for="tanggal">Tanggal Hari ini</label>
                <input type="date" id="tanggal" name="tanggal" class="form-control" max="<?php echo date('Y-m-d'); ?>" required>
            </div>
            <div class="mt-3">
                <label for="jam_pulang">Jam Pulang</label>
                <input type="time" id="jam_pulang" name="jam_pulang" class="form-control" required>
            </div>
            <div class="mt-3">
                <label for="laporan">Kegiatan Hari ini</label>
                <textarea class="form-control" name="laporan" id="laporan" rows="2"></textarea>
            </div>
            <div class="mt-3">
                <button class="btn btn-primary" name="presensi" type="presensi">Presensi</button>
            </div>
        </form>
    </div>
    <div class="alert-container mt-3">
        <?php
        // Ambil id_intern dari sesi
        $id_intern = $_SESSION['id_intern'];

        if(isset($_POST['presensi'])){
            $tanggal = htmlspecialchars($_POST['tanggal']);
            $jam_pulang = htmlspecialchars($_POST['jam_pulang']);
            $laporan = htmlspecialchars($_POST['laporan']);

            // Mendapatkan hari dari tanggal yang dipilih
            $hari = date('N', strtotime($tanggal));

            // Memeriksa apakah hari adalah Sabtu atau Minggu
            if ($hari == 6 || $hari == 7) {
                echo '<div class="alert-custom alert-custom-danger" role="alert">Maaf, Anda tidak dapat melakukan presensi pada hari Sabtu atau Minggu.</div>';
            } else {
                // Memeriksa apakah jam pulang kurang dari jam 5 sore
                if (strtotime($jam_pulang) < strtotime('17:00:00')) {
                    echo '<div class="alert-custom alert-custom-danger" role="alert">Jam pulang harus setelah jam 17:00.</div>';
                    echo '<meta http-equiv="refresh" content="4; url=presensi_pulang.php"';
                } else {
                    // Memeriksa apakah semua data telah diisi
                    if (!empty($id_intern) && !empty($tanggal) && !empty($jam_pulang) && !empty($laporan)) {
                        // Memeriksa apakah mahasiswa sudah absen pulang hari ini
                        $query = "SELECT * FROM absensi_pulang WHERE id_intern='$id_intern' AND tanggal='$tanggal'";
                        $result = mysqli_query($con, $query);
                        if (mysqli_num_rows($result) > 0) {
                            echo '<div class="alert-custom alert-custom-danger" role="alert">Anda sudah melakukan presensi pulang hari ini.</div>';
                        } else {
                            // Menambahkan query
                            $queryTambah = mysqli_query($con, "INSERT INTO absensi_pulang (id_intern, tanggal, jam_pulang, laporan) VALUES ('$id_intern', '$tanggal', '$jam_pulang', '$laporan')");
                            if($queryTambah) {
                                echo '<div class="alert alert-primary mt-3" role="alert">Terima kasih sudah presensi!</div>';
                                echo '<!---untuk auto refresh halaman--->
                                    <meta http-equiv="refresh" content="4; url=presensi_pulang.php" />';
                            } else {
                                // Tampilkan pesan kesalahan jika query gagal dieksekusi
                                echo '<div class="alert-custom alert-custom-danger" role="alert">'.mysqli_error($con).'</div>';
                            }
                        }
                    } else {
                        echo '<div class="alert alert-primary mt-3" role="alert">Mohon lengkapi semua datanya</div>';
                    }
                }
            }
        }
        ?>
    </div>
    </div>
    <script>
        function updateClock() {
            var now = new Date();
            var hours = now.getHours();
            var minutes = now.getMinutes();
            var seconds = now.getSeconds();

            // Padding zero if single digit
            hours = (hours < 10 ? "0" : "") + hours;
            minutes = (minutes < 10 ? "0" : "") + minutes;

            var timeString = hours + ':' + minutes;

            document.getElementById('jam_pulang').value = timeString;

            setTimeout(updateClock, 1000); // Update every second
        }

        // Call the function to initially display the time
        updateClock();
    </script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>
