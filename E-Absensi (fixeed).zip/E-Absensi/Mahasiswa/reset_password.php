<?php
    session_start();
    require "../koneksi.php";

    // Periksa apakah session username sudah terisi
    if(!isset($_SESSION['username']) || empty($_SESSION['username'])) {
        // Jika tidak, redirect ke halaman login
        header("Location: login.php");
        exit; // Penting untuk menghentikan eksekusi kode selanjutnya setelah melakukan redirect
    }

    // Pastikan koneksi database sudah dibuat dan disimpan di variabel $con
    if(isset($con)) {
        // Proses reset password jika form dikirim
        if(isset($_POST['proses'])) {
            // Ambil nilai dari form
            $username = $_SESSION['username'];
            $password_lama = $_POST['password_lama'];
            $password_baru = $_POST['password_baru'];
            $konfirmasi_password = $_POST['konfirmasi_password'];

            // Cek apakah password lama, password baru, dan konfirmasi password tidak kosong
            if(!empty($password_lama) && !empty($password_baru) && !empty($konfirmasi_password)) {
                // Cek apakah password baru dan konfirmasi password sama
                if($password_baru == $konfirmasi_password) {
                    // Ambil data pengguna dari database
                    $query = mysqli_query($con, "SELECT * FROM users WHERE username = '$username'");
                    $data = mysqli_fetch_array($query);

                    if($data) {
                        // Validasi apakah password lama sesuai dengan yang ada di database
                        if(password_verify($password_lama, $data['password'])) {
                            // Enkripsi password baru
                            $pass_baru = password_hash($password_baru, PASSWORD_DEFAULT);

                            // Update password baru
                            $update_query = mysqli_query($con, "UPDATE users SET password = '$pass_baru' WHERE username = '$username'");

                            if($update_query) {
                                echo "<script>alert('Password berhasil diubah!'); window.location='reset_password.php'</script>";
                            } else {
                                echo "<script>alert('Gagal mengubah password!'); window.location='reset_password.php'</script>";
                            }
                        } else {
                            echo "<script>alert('Maaf, password lama anda tidak sesuai!'); window.location='reset_password.php'</script>";
                        }
                    } else {
                        echo "<script>alert('Maaf, terjadi kesalahan dalam mengambil data pengguna.'); window.location='reset_password.php'</script>";
                    }
                } else {    
                    echo "<script>alert('Maaf, password baru dan konfirmasi password tidak sesuai!'); window.location='reset_password.php'</script>";
                }
            } else {
                echo "<script>alert('Maaf, semua field harus diisi!'); window.location='reset_password.php'</script>";
            }
        }
    } else {
        echo "<script>alert('Maaf, terjadi kesalahan dalam koneksi database.'); window.location='reset_password.php'</script>";
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <title>Reset Password</title>
    <style>
        .main{
            height: 100vh;
        }
        .reset-box{
            width: 400px;
            height: 400px;
            box-sizing: border-box;
            border-radius: 10px; 
            margin: auto;  
            margin-top: 30px;
        }
        body {
            font-family: Poppins;
        }
        .no-decoration {
            text-decoration: none;
            margin: 0 auto;
            display: block;
            text-align: center;
        }
        a {
            color: black;
        }
    </style>
</head>
<body>
    <?php require "sidebar_mahasiswa.php"; ?>

     <!---page content--->
     <div class="main" style="margin-left:350px; margin-top:90px;">
        <header class="container" style="padding-top:10px;">
            <h5><i class="fas fa-unlock"></i><b> Reset Password</b></h5>
        </header> 
            <div class="reset-box p-5 shadow ">
                <h3 class="text-center">Reset Password</h3>
                <form action="" method="post">
                    <input type="hidden" name="username" value="<?= $_SESSION['username'] ?>">
                    <div class="mb-3">
                        <label for="password_lama">Password Lama</label>
                        <input type="password" class="form-control" name="password_lama" id="password_lama" required>
                    </div>
                    <div class="mb-3">
                        <label for="password_baru">Password Baru</label>
                        <input type="password" class="form-control" name="password_baru" id="password_baru" required>
                    </div>
                    <div >
                        <label for="konfirmasi_password">Konfirmasi Password Baru</label>
                        <input type="password" class="form-control" name="konfirmasi_password" id="konfirmasi_password" required>
                    </div>
                    <div class="button-group mt-3">
                        <button class="btn btn-primary" type="submit" name="proses">Proses</button>
                        <button class="btn btn-danger" type="button" name="batal" onclick="window.location='reset_password.php'">Batal</button>
                    </div>
                </form>
            </div>
    </div>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>
