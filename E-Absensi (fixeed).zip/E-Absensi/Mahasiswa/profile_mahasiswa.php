<?php
session_start();
require "../koneksi.php";

// Inisialisasi variabel data
$data = array();

// Memeriksa apakah pengguna sudah login
if(isset($_SESSION['id_user'])){
    $id_intern = $_SESSION['id_intern'];

    // Mengambil data mahasiswa berdasarkan id_intern yang disimpan di sesi
    $query = "SELECT * FROM mahasiswaa WHERE id_intern='$id_intern'";
    $result = mysqli_query($con, $query);

    // Memeriksa apakah profil ditemukan 
    if(mysqli_num_rows($result) > 0){
        $data = mysqli_fetch_assoc($result);
    } else {
        echo "Data mahasiswa tidak ditemukan!";
    }
} else {
    echo "Pengguna belum login";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <title>Profile Mahasiswa Magang</title>
    <style>
        body, h1, h2, h3, h4 {
            font-size: 1.25rem;
            font-family: "Poppins", sans-serif;
            font-weight: bold;
        }
        .main {
            margin-left: 400px; /* Adjust according to the sidebar width */
            padding-top: 10px; /* Adjust according to the navbar height */
        }
        @media (max-width: 768px) {
            body, h1, h2, h3, h4 {
                font-size: 1rem;
            }
            .main {
                margin-left: 0;
                padding-top: 70px; /* Adjust according to the navbar height */
            }
        }
    </style>
</head>
<body>
    <!---sidebar--->
    <?php require "sidebar_mahasiswa.php"; ?>

    <!---page content--->
    <div class="container mt-5">
        <!-- <header class="text-start">
            <h5><i class="far fa-user"></i><b> Profile Mahasiswa</b></h5>
        </header> -->

        <div class="row justify-content-center">
            <div class="col-12 col-md-8 col-lg-6">
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="mt-5 mb-3">
                        <h5><i class="far fa-user"></i><b> Profile Mahasiswa</b></h5>
                    </div>
                    <div class="mb-3">
                        <label for="id_intern" class="form-label">Nomor Internship</label>
                        <input type="text" id="id_intern" name="id_intern" class="form-control" value="<?php echo isset($data['id_intern']) ? $data['id_intern'] : ''; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="nama" class="form-label">Nama Lengkap</label>
                        <input type="text" id="nama" name="nama" class="form-control" value="<?php echo isset($data['nama']) ? $data['nama'] : ''; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="jurusan" class="form-label">Jurusan</label>
                        <input type="text" id="jurusan" name="jurusan" class="form-control" value="<?php echo isset($data['jurusan']) ? $data['jurusan'] : ''; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="divisi" class="form-label">Divisi</label>
                        <input type="text" name="divisi" id="divisi" class="form-control" value="<?php echo isset($data['divisi']) ? $data['divisi'] : ''; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="universitas" class="form-label">Universitas</label>
                        <input type="text" id="universitas" name="universitas" class="form-control" value="<?php echo isset($data['universitas']) ? $data['universitas'] : ''; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="jenis_kelamin" class="form-label">Jenis Kelamin</label>
                        <select name="jenis_kelamin" id="jenis_kelamin" class="form-control">
                            <option value="">Pilih Jenis Kelamin</option>
                            <option value="Laki-Laki" <?php if(isset($data['jenis_kelamin']) && $data['jenis_kelamin'] == 'Laki-Laki') echo 'selected'; ?>>Laki-Laki</option>
                            <option value="Perempuan" <?php if(isset($data['jenis_kelamin']) && $data['jenis_kelamin'] == 'Perempuan') echo 'selected'; ?>>Perempuan</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="alamat" class="form-label">Alamat</label>
                        <textarea name="alamat" id="alamat" cols="8" rows="5" class="form-control"><?php echo isset($data['alamat']) ? $data['alamat'] : ''; ?></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="no_telepon" class="form-label">Nomor Handphone</label>
                        <input type="text" id="no_telpon" name="no_telpon" class="form-control" value="<?php echo isset($data['no_telpon']) ? $data['no_telpon'] : ''; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="username" class="form-label">Username</label>
                        <input type="username" id="username" name="username" class="form-control" value="<?php echo $data['username']; ?>" required>
                    </div>
                    <div class="mt-3">
                        <a class="btn btn-primary" href="reset_password.php" role="button">Reset Password</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>
