<?php
session_start();
require "../koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Presensi Mahasiswa Magang</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <style>
        body, h1, h2, h3, h4 {
            font-size: 1.25rem;
            font-family: "Poppins", sans-serif;
            font-weight: bold;
        }
        .card {
            max-width: 100%;
            background-color: #EEEEEE;
            border: 2px solid #31363F;
            margin: auto;
            padding: 20px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
            box-sizing: border-box;
        }
        #pesan-telat {
            display: flex;
            justify-content: center;
            align-items: center;
            max-width: 90%;
            margin: auto;
            margin-top: 20px;
            padding: 10px;
            text-align: center;
            border: 1px solid #ffc107;
            border-radius: 5px;
            background-color: #fff3cd;
            color: #856404;
            font-size: 16px;
        }
        .main {
            margin: 0 auto;
            padding: 10px;
            max-width: 600px;
        }
        .modal-content {
            font-size: 1rem;
        }
    </style>
</head>
<body>
    <!---sidebar & navbar--->
    <?php require "sidebar_mahasiswa.php"; ?>

    <!---page content--->
    <div class="main">
        <header class="container" style="padding-top:90px;">
            <h5><i class="fas fa-user-clock"></i><b> Presensi</b></h5>
        </header>

        <!--content-->
        <div class="card shadow mt-3">
            <form id="presensiForm" method="post" enctype="multipart/form-data">
                <div class="mt-3">
                    <label for="tanggal">Tanggal Hari ini</label>
                    <input type="date" id="tanggal" name="tanggal" class="form-control" max="<?php echo date('Y-m-d'); ?>" required>
                </div>
                <div class="mt-3" id="jam-section">
                    <label for="jam_presensi">Jam</label>
                    <input type="time" id="jam_presensi" name="jam_presensi" class="form-control" required>
                </div>
                <div class="mt-3" id="laporan-section" style="display: none;">
                    <label for="laporan">Kegiatan Hari ini</label>
                    <textarea class="form-control" name="laporan" id="laporan" rows="2"></textarea>
                </div>
                <div class="mt-3" id="keterangan-section">
                    <label for="keterangan">Keterangan</label>
                    <select class="form-select" aria-label="Default select example" name="keterangan" id="keterangan">
                        <option selected>Pilih Keterangan Kehadiran</option>
                        <option value="Hadir">Hadir</option>
                        <option value="Izin">Izin</option>
                        <option value="Sakit">Sakit</option>
                    </select>
                </div>
                <div class="mt-3" id="file-upload" style="display: none;">
                    <label for="file">Masukkan file</label>
                    <input class="form-control" name="file" id="file" type="file" accept="application/pdf">
                </div>
                <div class="mt-3">
                    <button class="btn btn-primary" name="presensi" type="submit">Presensi</button>
                </div>
            </form>
        </div>

        <!-- Modal HTML -->
        <div class="modal fade" id="alertModal" tabindex="-1" aria-labelledby="alertModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="alertModalLabel">Pemberitahuan</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Message will be inserted here -->
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Div pesan telat -->
        <div id="pesan-telat" class="alert alert-warning mt-3" style="display: none;"></div>

        <div class="alert-container mt-3">
        <?php
            // Ambil id_intern dari sesi
            $id_intern = $_SESSION['id_intern'];

            if (isset($_POST['presensi'])) {
                $tanggal = htmlspecialchars($_POST['tanggal']);
                $jam_presensi = isset($_POST['jam_presensi']) ? htmlspecialchars($_POST['jam_presensi']) : null;
                $laporan = isset($_POST['laporan']) ? htmlspecialchars($_POST['laporan']) : null;
                $keterangan = isset($_POST['keterangan']) ? htmlspecialchars($_POST['keterangan']) : null;
                $current_time = date("H:i:s");

                // Mendapatkan hari dari tanggal yang dipilih
                $hari = date('N', strtotime($tanggal));

                // Validasi untuk hari Sabtu dan Minggu
                if ($hari >= 6) {
                    echo '<script>
                            var myModal = new bootstrap.Modal(document.getElementById("alertModal"));
                            document.querySelector(".modal-body").textContent = "Maaf, Anda tidak dapat melakukan absensi pada hari Sabtu atau Minggu.";
                            myModal.show();
                          </script>';
                } else {
                    // Validasi apakah mahasiswa telah melakukan absensi datang hari ini
                    $query_datang = "SELECT * FROM absensi_datang WHERE id_intern='$id_intern' AND tanggal='$tanggal'";
                    $result_datang = mysqli_query($con, $query_datang);
                    $is_absen_datang = mysqli_num_rows($result_datang) > 0;

                    // Validasi apakah mahasiswa telah melakukan absensi pulang hari ini
                    $query_pulang = "SELECT * FROM absensi_pulang WHERE id_intern='$id_intern' AND tanggal='$tanggal'";
                    $result_pulang = mysqli_query($con, $query_pulang);
                    $is_absen_pulang = mysqli_num_rows($result_pulang) > 0;

                    // Logika untuk absensi datang dan pulang
                    if ($current_time <= '12:00:00' && !$is_absen_datang) {
                        // Logika untuk absensi datang sebelum jam 12 siang
                        if ($keterangan == "Hadir") {
                            $jam_datang_timestamp = strtotime($jam_presensi);
                            $jam_batas = strtotime('08:00:00');

                            if ($jam_datang_timestamp > $jam_batas) {
                                $telat_menit = floor(($jam_datang_timestamp - $jam_batas) / 60);
                                echo '<script>
                                        document.getElementById("pesan-telat").innerHTML = "Anda datang telat sekitar ' . $telat_menit . ' menit.";
                                        document.getElementById("pesan-telat").style.display = "block";
                                        var meta = document.createElement("meta");
                                        meta.httpEquiv = "refresh";
                                        meta.content = "5"; // Refresh setelah 5 detik
                                        document.getElementsByTagName("head")[0].appendChild(meta);
                                      </script>';
                            }
                        }

                        if ($keterangan == "Izin" || $keterangan == "Sakit") {
                            if (isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])) {
                                $file_name = $_FILES['file']['name'];
                                $file_tmp = $_FILES['file']['tmp_name'];
                                $file_destination = "../uploads/" . $file_name;

                                if (!is_dir("../uploads/")) {
                                    mkdir("../uploads/", 0777, true);
                                }

                                if (move_uploaded_file($file_tmp, $file_destination)) {
                                    $insert_query = "INSERT INTO absensi_datang (id_intern, tanggal, jam_datang, keterangan, file) VALUES ('$id_intern', '$tanggal', '$jam_presensi', '$keterangan', '$file_name')";
                                    $result = mysqli_query($con, $insert_query);
                                    if ($result) {
                                        echo '<script>
                                                var myModal = new bootstrap.Modal(document.getElementById("alertModal"));
                                                document.querySelector(".modal-body").textContent = "Terima kasih sudah presensi!";
                                                myModal.show();
                                              </script>';
                                    } else {
                                        echo '<script>
                                                var myModal = new bootstrap.Modal(document.getElementById("alertModal"));
                                                document.querySelector(".modal-body").textContent = "Gagal mengisi presensi!";
                                                myModal.show();
                                              </script>';
                                    }
                                } else {
                                    echo '<script>
                                            var myModal = new bootstrap.Modal(document.getElementById("alertModal"));
                                            document.querySelector(".modal-body").textContent = "Gagal mengupload file.";
                                            myModal.show();
                                          </script>';
                                }
                            } else {
                                echo '<script>
                                        var myModal = new bootstrap.Modal(document.getElementById("alertModal"));
                                        document.querySelector(".modal-body").textContent = "File harus diupload jika memilih keterangan izin atau sakit.";
                                        myModal.show();
                                      </script>';
                            }
                        } else {
                            $insert_query = "INSERT INTO absensi_datang (id_intern, tanggal, jam_datang, keterangan) VALUES ('$id_intern', '$tanggal', '$jam_presensi', '$keterangan')";
                            $result = mysqli_query($con, $insert_query);
                            if ($result) {
                                echo '<script>
                                        var myModal = new bootstrap.Modal(document.getElementById("alertModal"));
                                        document.querySelector(".modal-body").textContent = "Terima kasih sudah presensi!";
                                        myModal.show();
                                      </script>';
                            } else {
                                echo '<script>
                                        var myModal = new bootstrap.Modal(document.getElementById("alertModal"));
                                        document.querySelector(".modal-body").textContent = "Maaf terjadi kesalahan.";
                                        myModal.show();
                                      </script>';
                            }
                        }
                    } elseif ($current_time > '12:00:00' && !$is_absen_pulang) {
                        // Logika untuk absensi pulang setelah jam 12 siang
                        $insert_query = "INSERT INTO absensi_pulang (id_intern, tanggal, jam_pulang, laporan) VALUES ('$id_intern', '$tanggal', '$jam_presensi', '$laporan')";
                        $result = mysqli_query($con, $insert_query);
                        if ($result) {
                            echo '<script>
                                    var myModal = new bootstrap.Modal(document.getElementById("alertModal"));
                                    document.querySelector(".modal-body").textContent = "Terima kasih sudah presensi pulang!";
                                    myModal.show();
                                  </script>';
                        } else {
                            echo '<script>
                                    var myModal = new bootstrap.Modal(document.getElementById("alertModal"));
                                    document.querySelector(".modal-body").textContent = "Maaf terjadi kesalahan.";
                                    myModal.show();
                                  </script>';
                        }
                    } else {
                        echo '<script>
                                var myModal = new bootstrap.Modal(document.getElementById("alertModal"));
                                document.querySelector(".modal-body").textContent = "Maaf, Anda sudah melakukan presensi hari ini.";
                                myModal.show();
                              </script>';
                    }
                }
            }
        ?>
        </div>
    </div>

    <script>
    function updateClock() {
        var now = new Date();
        var hours = now.getHours();
        var minutes = now.getMinutes();

        // Padding zero if single digit
        hours = (hours < 10 ? "0" : "") + hours;
        minutes = (minutes < 10 ? "0" : "") + minutes;

        var timeString = hours + ':' + minutes;

        document.getElementById('jam_presensi').value = timeString;

        setTimeout(updateClock, 1000); // Update every second
    }

    function checkFileUpload() {
        var keterangan = document.getElementById('keterangan').value;
        var fileUpload = document.getElementById('file-upload');

        if (keterangan === 'Izin' || keterangan === 'Sakit') {
            fileUpload.style.display = 'block';
        } else {
            fileUpload.style.display = 'none';
        }
    }

    function checkLaporan() {
        var now = new Date();
        var hours = now.getHours();
        var laporanSection = document.getElementById('laporan-section');

        if (hours >= 12) {
            laporanSection.style.display = 'block';
            document.getElementById('keterangan-section').style.display = 'none';
        } else {
            laporanSection.style.display = 'none';  
        }
    }

    function setCurrentDate() {
        var now = new Date();
        var year = now.getFullYear();
        var month = (now.getMonth() + 1).toString().padStart(2, '0'); // getMonth() returns 0-11
        var day = now.getDate().toString().padStart(2, '0');
        var currentDate = `${year}-${month}-${day}`;

        document.getElementById('tanggal').value = currentDate;
    }

    // Call the functions to initially display the time, set current date, and check file upload visibility
    updateClock();
    setCurrentDate();
    checkFileUpload();
    checkLaporan();

    // Add event listener to the keterangan select element
    document.getElementById('keterangan').addEventListener('change', checkFileUpload);
    </script>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>
