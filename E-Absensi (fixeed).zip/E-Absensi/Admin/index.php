<?php
session_start();
require "../koneksi.php";

// Debugging output
if (!isset($con)) {
    die("Database connection not established.");
}

// Fetch attendance data for the graph
$query = "SELECT DATE_FORMAT(tanggal, '%Y-%m') as month, COUNT(id_intern) as attendance_count
          FROM absensi_datang
          WHERE keterangan = 'hadir'
          GROUP BY month
          ORDER BY month ASC";
$result = $con->query($query);

$attendance_data = array();
while($row = $result->fetch_assoc()) {
    $attendance_data[] = $row;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-size: 20px;
            font-family: "Poppins", sans-serif; 
        }
        .no-decoration {
            text-decoration: none;
        }
        .chart-container {
            width: 75%;
            margin: auto;
        }
        @media (max-width: 768px) {
            body {
                font-size: 16px;
            }
            .main {
                margin-left: 0;
                margin-top: 70px;
                padding: 15px;
            }
            .chart-container {
                width: 100%;
            }
            .card-title {
                font-size: 1rem;
            }
            .card-body i {
                font-size: 1.5rem;
            }
        }
        .card {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!---bagian sidebar--->
    <?php require "sidebar.php"; ?>
    <!---Page Content--->
    <div class="main" style="margin-left:350px;margin-top:90px;">
        <!---header--->
        <header class="container" style="padding-top:10px;">
            <h5><b><i class="fa fa-dashboard"></i> Dashboard</b></h5>
        </header>

        <div class="container-fluid">
            <div class="row no-gutters">
                <div class="col-12 col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="far fa-folder-open"></i>
                            <h5 class="card-title">Data Mahasiswa</h5>
                            <a href="data_mahasiswa.php" class="text-dark no-decoration">Lihat Data Mahasiswa</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="far fa-folder-open"></i>
                            <h5 class="card-title">Data Presensi</h5>
                            <a href="rekap_presensi.php" class="text-dark no-decoration">Lihat Data Presensi</a>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-md-4 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <i class="fas fa-user"></i>
                            <h5 class="card-title">Daftar Akun</h5>
                            <a href="register.php" class="text-dark no-decoration">Tambah akun</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <!-- Attendance Chart -->
        <div class="chart-container">
            <canvas id="attendanceChart"></canvas>
        </div>
    </div>

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
    <script>
        // Prepare data for the chart
        const attendanceData = <?php echo json_encode($attendance_data); ?>;
        
        // Create a map for month names
        const monthNames = {
            '01': 'January', '02': 'February', '03': 'March', '04': 'April',
            '05': 'May', '06': 'June', '07': 'July', '08': 'August',
            '09': 'September', '10': 'October', '11': 'November', '12': 'December'
        };
        
        // Extract year and month separately
        const labels = attendanceData.map(data => {
            const [year, month] = data.month.split('-');
            return monthNames[month] + ' ' + year;
        });
        const data = attendanceData.map(data => data.attendance_count);

        // Create the chart
        const ctx = document.getElementById('attendanceChart').getContext('2d');
        const attendanceChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Data Kehadiran Mahasiswa Magang',
                    data: data,
                    backgroundColor: 'rgba(54, 162, 235, 0.2)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>
