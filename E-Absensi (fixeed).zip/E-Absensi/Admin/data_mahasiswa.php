<?php
    session_start();
    require "../koneksi.php";
    //database data_mahasiswa
    $query = mysqli_query($con, "SELECT * FROM mahasiswaa");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Mahasiswa || Admin</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <style>
        body {
            font-size: 20px;
            font-family: "Poppins", sans-serif;
            margin: 20px; /* Menambahkan margin di sekitar halaman */
        }
       /* CSS untuk mengatur tata letak teks di dalam tabel */
       .table {
            text-align: center; /* Menengahkan teks secara horizontal */
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.20); 
            font-size: 1.0rem;
            width: 100%;
            margin: 20px 0; /* Menambahkan margin atas dan bawah */
            border-collapse: collapse; /* Menggabungkan batas sel */
        }
        .table th,
        .table td {
            vertical-align: middle; /* Menengahkan teks secara vertikal */
            border: 1px solid #ddd; /* Mengatur warna garis batas */
            padding: 12px; /* Menambahkan padding untuk membuat teks lebih mudah dibaca */
        }
        .table thead {
            background-color: #948979;
            color: white; /* Mengatur warna teks header */
        }
        .table tbody tr:hover {
            background-color: #f5f5f5; /* Menambahkan efek hover pada baris tabel */
        }
        .table-responsive {
            overflow-x: auto;
        }
        .btn.warna3 {
            background-color: #948979; /* Sesuaikan dengan warna yang diinginkan */
            color: white;
        }
        .btn.warna3:hover {
            background-color: #746856; /* Warna yang lebih gelap saat dihover */
        }
    </style>
</head> 
<body>
    <!----bagian sidebar---->
    <?php require "sidebar.php"; ?>
    <!---page content--->
    <div class="main" style="margin-left:350px; margin-top:90px;">
        <header class="container" style="padding-top:10px">
            <h5><b><i class="fas fa-user-edit"></i> Tambah Data Mahasiswa</b></h5>
        </header>
        <!---tambah data mahasiswa--->
        <div>
            <a class="btn btn-primary mt-3" href="datamahasiswa_tambah.php" role="button">Tambah Data Mahasiswa</a>
        </div>
    </div>
    <!---membuat tabel untuk list data_mahasiswa--->
    <div class="main" style="margin-left:350px; margin-top:20px;">
        <h4><b>List Data Mahasiswa Magang</b></h4>
        <div class="table-responsive mt-7">
            <table class="table">
                <thead>
                    <tr>
                        <th>Nomor Internship</th>
                        <th>Nama</th>
                        <th>Jurusan</th>
                        <th>Divisi</th>
                        <th>Universitas</th>
                        <th>Jenis Kelamin</th>
                        <th>Alamat</th>
                        <th>Nomor Telepon</th>
                        <th>Username</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Melakukan iterasi untuk setiap baris data dari hasil query
                    while ($data = mysqli_fetch_assoc($query)) {
                        // Menampilkan data pada setiap kolom
                        ?>
                        <tr>
                            <td><?php echo $data['id_intern']; ?></td>
                            <td><?php echo $data['nama']; ?></td>
                            <td><?php echo $data['jurusan']; ?></td>
                            <td><?php echo $data['divisi']; ?></td>
                            <td><?php echo $data['universitas']; ?></td>
                            <td><?php echo $data['jenis_kelamin']; ?></td>
                            <td><?php echo $data['alamat']; ?></td>
                            <td><?php echo $data['no_telpon']; ?></td>
                            <td><?php echo $data['username']; ?></td>
                            <td>
                                <a href="datamahasiswa_detail.php?q=<?php echo $data['id_intern']; ?>" class="btn warna3">
                                    <i class="fas fa-sliders"></i>
                                </a>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>
