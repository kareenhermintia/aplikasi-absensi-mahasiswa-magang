<?php
session_start();
require "../koneksi.php";

// Pastikan $id_intern sudah ada sebelum disimpan ke dalam session
if (isset($_GET['q'])) {
    $id_intern = $_GET['q'];
    $_SESSION['id_intern'] = $id_intern;
} else {
    echo "<script>alert('ID intern tidak tersedia.'); window.location.href = 'rekap_presensi.php';</script>";
    exit;
}

// Query untuk mendapatkan data absensi datang
$query_absensi_datang = "SELECT tanggal, jam_datang, keterangan, file FROM absensi_datang WHERE id_intern = '$id_intern'";
$result_datang = mysqli_query($con, $query_absensi_datang);
$data_datang = mysqli_fetch_all($result_datang, MYSQLI_ASSOC);

$query_absensi_pulang = "SELECT tanggal, jam_pulang, laporan FROM absensi_pulang WHERE id_intern = '$id_intern'";
$result_pulang = mysqli_query($con, $query_absensi_pulang);
$data_pulang = mysqli_fetch_all($result_pulang, MYSQLI_ASSOC);

// Menggabungkan data absensi datang dan pulang
$data = [];
foreach ($data_datang as $datang) {
    $tanggal = $datang['tanggal'];
    $keterangan = $datang['keterangan'];
    $data[$tanggal] = [
        'tanggal' => $tanggal,
        'jam_datang' => $datang['jam_datang'],
        'keterangan' => $keterangan,
        'file' => $datang['file'],
        'jam_pulang' => '',
        'laporan' => ''
    ];
}

foreach ($data_pulang as $pulang) {
    $tanggal = $pulang['tanggal'];
    if (isset($data[$tanggal])) {
        // Jika keterangan adalah izin atau sakit, kosongkan jam_pulang dan laporan
        if ($data[$tanggal]['keterangan'] == 'Izin' || $data[$tanggal]['keterangan'] == 'Sakit') {
            $data[$tanggal]['jam_pulang'] = '';
            $data[$tanggal]['laporan'] = '';
        } else {
            $data[$tanggal]['jam_pulang'] = $pulang['jam_pulang'];
            $data[$tanggal]['laporan'] = $pulang['laporan'];
        }
    } else {
        $data[$tanggal] = [
            'tanggal' => $tanggal,
            'jam_datang' => '',
            'keterangan' => '',
            'file' => '',
            'jam_pulang' => $pulang['jam_pulang'],
            'laporan' => $pulang['laporan']
        ];
    }
}

// Ambil nama mahasiswa
$mahasiswa_query = "SELECT nama FROM mahasiswaa WHERE id_intern = '$id_intern'";
$result_mahasiswa = mysqli_query($con, $mahasiswa_query);
$mahasiswa = mysqli_fetch_assoc($result_mahasiswa);
$nama = $mahasiswa['nama'];

// Proses update data
if (isset($_POST['simpan'])) {
    $tanggal = $_POST['tanggal'];
    $jam_datang = $_POST['jam_datang'];
    $jam_pulang = $_POST['jam_pulang'];
    $keterangan = $_POST['keterangan'];
    $laporan = $_POST['laporan'];
    $nama = $_POST['nama'];

    // Jika keterangan adalah izin atau sakit, kosongkan nilai jam datang dan jam pulang
    if ($keterangan == 'Izin' || $keterangan == 'Sakit') {
        $jam_datang = '';
        $jam_pulang = '';
    }

    // Simpan file jika diunggah
    $file_destination = '';
    if (isset($_FILES['file']) && $_FILES['file']['error'] == UPLOAD_ERR_OK) {
        $file_name = $_FILES['file']['name'];
        $file_tmp = $_FILES['file']['tmp_name'];
        $file_destination = '../uploads/' . uniqid() . '_' . $file_name; // Nama file disesuaikan agar unik
        move_uploaded_file($file_tmp, $file_destination);
    }

    // Update query
    if ($keterangan == 'Izin' || $keterangan == 'Sakit') {
        // Kondisi untuk izin atau sakit
        $update_query = mysqli_query($con, "UPDATE absensi_datang 
                                            SET keterangan = '$keterangan', 
                                                file = '$file_destination', 
                                                jam_datang = '$jam_datang' 
                                            WHERE id_intern = '$id_intern' AND tanggal = '$tanggal'");
    } else {
        // Kondisi untuk hadir
        $update_query = mysqli_query($con, "UPDATE absensi_datang ad
                                            JOIN absensi_pulang ap ON ad.id_intern = ap.id_intern AND ad.tanggal = ap.tanggal
                                            SET ad.jam_datang = '$jam_datang', 
                                                ad.keterangan = '$keterangan', 
                                                ad.file = '$file_destination', 
                                                ap.jam_pulang = '$jam_pulang', 
                                                ap.laporan = '$laporan' 
                                            WHERE ad.id_intern = '$id_intern' AND ad.tanggal = '$tanggal'");
    }

    if ($update_query) {
        echo "<script>alert('Data mahasiswa berhasil diupdate'); window.location.href = 'rekap_presensi.php';</script>";
        exit();
    } else {
        echo "<script>alert('Gagal memperbarui data.');</script>";
    }
}

// Proses hapus data
if (isset($_POST['hapus'])) {
    $tanggal = $_POST['tanggal'];
    $delete_query = mysqli_query($con, "DELETE FROM absensi_datang WHERE id_intern = '$id_intern' AND tanggal = '$tanggal'");
    
    if ($delete_query) {
        echo "<script>alert('Data berhasil dihapus.'); window.location.href = 'rekap_presensi.php';</script>";
        exit();
    } else {
        echo "<script>alert('Gagal menghapus data.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Presensi Detail || Admin</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
</head>
<style>
    body {
        font-size: 20px;
        font-family: "Poppins", sans-serif;
    }
    form div {
        margin-bottom: 10px;
    }
</style>
<body>
    <!---sidebar--->
    <?php require "sidebar.php"; ?>

    <!---konten halaman--->
    <div class="main" style="margin-left:350px; margin-top:90px;">
        <header class="container" style="padding-top:10px">
            <h5><b><i class="far fa-edit"></i> Edit Rekap Presensi</b></h5>
        </header>

        <!---form data mahasiswa_detail--->
        <div class="my-5 col-12 col-md-6">
            <h4>Rekap Presensi</h4>
            <form action="" method="post" enctype="multipart/form-data">
                <input type="hidden" name="id_intern" value="<?php echo $id_intern; ?>">
                <div>
                    <label for="tanggal">Tanggal</label>
                    <select id="tanggal" name="tanggal" class="form-control" required>
                        <option value="">Pilih Tanggal</option>
                        <?php foreach ($data as $item): ?>
                            <option value="<?php echo $item['tanggal']; ?>"><?php echo $item['tanggal']; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label for="jam_datang">Jam Datang</label>
                    <input type="time" id="jam_datang" name="jam_datang" class="form-control">
                </div>
                <div>
                    <label for="jam_pulang">Jam Pulang</label>
                    <input type="time" id="jam_pulang" name="jam_pulang" class="form-control">
                </div>
                <div>
                    <label for="keterangan">Keterangan</label>
                    <select name="keterangan" id="keterangan" class="form-control" required>
                        <option value="">Pilih Keterangan</option>
                        <option value="Hadir">Hadir</option>
                        <option value="Izin">Izin</option>
                        <option value="Sakit">Sakit</option>
                    </select>
                </div>
                <div>
                    <label for="laporan">Laporan</label>
                    <textarea name="laporan" id="laporan" cols="10" rows="5" class="form-control"></textarea>
                </div>
                <div>
                    <label for="file">File</label>
                    <input class="form-control" name="file" id="file" type="file" accept="application/pdf">
                </div>
                <div>
                    <label for="nama">Nama Mahasiswa</label>
                    <input type="text" id="nama" name="nama" class="form-control" value="<?php echo $nama; ?>" required>
                </div>
                <div>
                    <button type="submit" class="btn btn-primary" name="simpan">Update</button>
                    <button type="submit" class="btn btn-danger" name="hapus">Delete</button>
                </div>
            </form>
        </div>    

        <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="../fontawesome/js/all.min.js"></script>
        <script>
            // JavaScript untuk menangani perubahan keterangan
            document.getElementById('keterangan').addEventListener('change', function () {
            var keterangan = this.value.toLowerCase();
            var jamDatang = document.getElementById('jam_datang');
            var jamPulang = document.getElementById('jam_pulang');
            var laporan = document.getElementById('laporan');
            
            if (keterangan === 'izin' || keterangan === 'sakit') {
                jamDatang.value = '';
                jamDatang.readOnly = true;
                jamPulang.value = '';
                jamPulang.readOnly = true;
                laporan.value = '';
                laporan.readOnly = true;
            } else {
                jamDatang.readOnly = false;
                jamPulang.readOnly = false;
                laporan.readOnly = false;
            }
        });

    // Event untuk mengatur kolom dengan benar berdasarkan tanggal yang dipilih
    document.getElementById('tanggal').addEventListener('change', function () {
        var tanggal = this.value;
        var data = <?php echo json_encode($data); ?>;
        if (data[tanggal]) {
            document.getElementById('jam_datang').value = data[tanggal]['jam_datang'];
            document.getElementById('jam_pulang').value = data[tanggal]['jam_pulang'];
            document.getElementById('keterangan').value = data[tanggal]['keterangan'];
            document.getElementById('laporan').value = data[tanggal]['laporan'];
        } else {
            document.getElementById('jam_datang').value = '';
            document.getElementById('jam_pulang').value = '';
            document.getElementById('keterangan').value = '';
            document.getElementById('laporan').value = '';
        }
        document.getElementById('keterangan').dispatchEvent(new Event('change'));
    });

        </script>
    </div>
</body>
</html>
