<?php
    // Pastikan tidak ada output sebelum session_start()
    session_start();
    require "../koneksi.php";

    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['register'])) {
        $email = htmlspecialchars($_POST['email']);
        $nama = htmlspecialchars($_POST['nama']);
        $password = htmlspecialchars($_POST['password']);
        $level = $_POST['level'];

        // Validasi data
        if (empty($email) || empty($nama) || empty($password) || $level == "Pilih register sebagai") {
            echo '<div class="alert alert-danger mt-3" role="alert">Harap isi semua kolom dengan benar!</div>';
        } else {
            // Hash password sebelum disimpan ke dalam database
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Jika level adalah "Mahasiswa", dapatkan id_intern
            if ($level == "Mahasiswa") {
                $id_intern = htmlspecialchars($_POST['id_intern']);
            } else {
                $id_intern = NULL; // Atau isi dengan nilai default yang sesuai
            }

            // Query untuk menyimpan data register ke dalam database
            $query = "INSERT INTO users (username,  nama, id_intern, password, level) VALUES (?, ?, ?, ?, ?)";
            $stmt = mysqli_prepare($con, $query);
            
            // Bind parameter ke query
            mysqli_stmt_bind_param($stmt, "sssss", $email, $nama, $id_intern, $hashed_password, $level);

            // Eksekusi query
            $result = mysqli_stmt_execute($stmt);
            
            if($result) {
                // Jika berhasil
                $_SESSION['success_msg'] = "Register Berhasil!";
                header('Location: ../login.php');
                exit(); // Pastikan tidak ada output sebelum header dipanggil
            } else {
                // Jika gagal
                echo '<div class="alert alert-danger mt-3" role="alert">Registrasi gagal. Silakan coba lagi!</div>';
            }
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Akun Mahasiswa || Admin</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <style>
        body {
            font-size: 20px;
            font-family: "Poppins", sans-serif;
        }
        .register-card {
        width: 400px; /* Lebar kartu */
        height: auto; /* Tinggi kartu menyesuaikan konten */
        border-radius: 10px;  
        margin: auto;
        padding: 20px; /* Menambahkan padding agar konten tidak terlalu dekat dengan pinggir kartu */
        box-sizing: content-box; /* Memastikan padding tidak dimasukkan dalam perhitungan lebar kartu */
        overflow: hidden; /* Konten yang terlalu lebar akan dipotong */
        }
        .container-card {
            width: 200px; /* Lebar container kartu */
            margin: 40px auto 0 auto; /* Atur margin atas, dan margin kiri-kanan otomatis agar terpusat */
        }
        .mt-2 {
            margin-top: 15px; /* Mengurangi jarak antara elemen dengan kelas mt-3 */
        }
        .btn-primary {
            margin-top: 3px; /* Mengurangi jarak antara tombol register dengan elemen di atasnya */
            width: 100%;
        }
    </style>
</head>
<body>
    <!--sidebar-->
    <?php require "sidebar.php"; ?>

    <!---page content--->
    <div class="main" style="margin-left:350px;margin-top:90px;">
        <!--header-->
        <header class="container" style="padding-top:10px;">
            <h5><b><i class="far fa-user-circle"></i> Tambah Akun</b></h5>
        </header>

        <div class="container container-card card" style="width:500px; height:500px;">
            <div class="register-card">
                <form action="" method="post" enctype="multipart/form">
                    <div class="mt-2">
                        <label for="email">Username</label>
                        <input type="email" name="email" id="email" class="form-control">
                    </div>
                    <div class="mt-2">
                        <label for="nama">Nama</label>
                        <input type="text" name="nama" id="nama" class="form-control">
                    </div>
                    <div class="mt-2">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" class="form-control">
                    </div>
                    <div class="mt-2">
                        <label for="level">Pilih register sebagai</label>
                        <select class="form-select" aria-label="Default select example" name="level" id="level">
                            <option selected>Pilih register sebagai</option>
                            <option value="Mahasiswa">Mahasiswa</option>
                            <option value="Admin">Admin</option>
                        </select>
                    </div>
                    <div class="mt-3" id="id_intern_container" style="display: none;">
                        <label for="id_intern">Nomer Internship</label>
                        <input type="text" name="id_intern" id="id_intern" class="form-control">
                    </div>
                    <div class="mt-3">
                        <button class="btn btn-primary" type="submit" name="register">Register</button>
                    </div>
                </form>
            </div>
            <?php
                if(isset($_SESSION['success_msg'])) {
                    echo '<div class="alert alert-primary mt-6" role="alert">' . $_SESSION['success_msg'] . '</div>';
                    unset($_SESSION['success_msg']);
                }
            ?>
        </div>
    </div>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
    <script>
        // Tampilkan input id_intern jika level dipilih adalah "Mahasiswa"
        document.getElementById('level').addEventListener('change', function() {
            var idInternContainer = document.getElementById('id_intern_container');
            if (this.value === 'Mahasiswa') {
                idInternContainer.style.display = 'block';
            } else {
                idInternContainer.style.display = 'none';
            }
        });
    </script>
</body>
</html>
