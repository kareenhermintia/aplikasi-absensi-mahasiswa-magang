<?php
session_start();
require "../koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rekap Presensi Admin</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <style>
        body {
            font-size: 20px;
            font-family: "Poppins", sans-serif;
            margin: 20px;
        }
        .table {
            text-align: center;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.20);
            font-size: 1.0rem;
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
        }
        .table th,
        .table td {
            vertical-align: middle;
            border: 1px solid #ddd;
            padding: 12px;
        }
        .table thead {
            background-color: #948979;
            color: white;
        }
        .table tbody tr:hover {
            background-color: #f5f5f5;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .btn.warna3 {
            background-color: #948979;
            color: white;
        }
        .btn.warna3:hover {
            background-color: #746856;
        }
        .table-container {
            margin: 0 auto;
            width: 95%;
            display: block;
            padding-top: 5px;
        }
        #pagination {
            margin-top: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .pagination-btn {
            background-color: #28a745;
            color: #fff;
            border: none;
            padding: 8px 12px;
            margin: 0 2px;
            cursor: pointer;
            border-radius: 3px;
        }
        .pagination-btn:hover {
            background-color: #218838;
        }
        .pagination-info {
            margin: 0 10px;
        }
    </style>
</head>
<body>
    <?php require "sidebar.php"; ?>

    <div class="main" style="margin-left:350px;margin-top:90px;">
        <header class="container" style="padding-top:10px;">
            <h5><b><i class="far fa-folder"></i> Rekap Presensi</b></h5>
        </header>

        <div class="container-fluid">
            <form action="" method="post" enctype="multipart/form-data">
                <div class="row p-3" style="padding-left: 10px;">
                    <div class="col">
                        <label for="tanggal_awal">Tanggal Awal</label>
                        <input type="date" name="tanggal_awal" id="tanggal_awal" class="form-control" placeholder="Tanggal Awal" aria-label="Tanggal Awal">
                    </div>
                    <div class="col"> 
                        <label for="tanggal_akhir">Tanggal Akhir</label>
                        <input type="date" name="tanggal_akhir" id="tanggal_akhir" class="form-control" placeholder="Tanggal Akhir" aria-label="Tanggal Akhir">
                    </div>
                    <div class="col">
                        <label for="id_intern">Pilih Mahasiswa:</label>
                        <select class="form-select" name="id_intern" id="id_intern">
                            <option value="all">Semua Mahasiswa</option>
                            <?php 
                            $query_mahasiswa = "SELECT id_intern, nama FROM mahasiswaa";
                            $result_mahasiswa = mysqli_query($con, $query_mahasiswa);
                            
                            while ($row_mahasiswa = mysqli_fetch_assoc($result_mahasiswa)): ?>
                                <option value="<?php echo $row_mahasiswa['id_intern']; ?>"><?php echo $row_mahasiswa['nama']; ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="col">
                        <br>
                        <button class="btn btn-primary btn-sm" type="submit" name="submit">Lihat Rekapan</button>
                        <a class="btn btn-secondary btn-sm" href="cetak_laporan.php" role="button">Cetak Presensi</a>
                    </div>
                </div>
            </form>
        </div>

        <?php
        if(isset($_POST['submit'])){
            $tanggal_awal = htmlspecialchars($_POST['tanggal_awal']);
            $tanggal_akhir = htmlspecialchars($_POST['tanggal_akhir']);
            $mahasiswa_id = htmlspecialchars($_POST['id_intern']);

            $query_absensi_datang = "SELECT tanggal, jam_datang, '' AS jam_pulang, keterangan, '' AS laporan, file, id_intern,
                                        CASE WHEN TIME(jam_datang) > '08:00:00' THEN 'Datang Telat' 
                                        WHEN TIME(jam_datang) = '08:00:00' THEN 'Datang Tepat Waktu' 
                                        ELSE 'Datang Tepat Waktu' END AS status_datang,
                                        '' AS status_pulang
                                        FROM absensi_datang WHERE tanggal BETWEEN '$tanggal_awal' AND '$tanggal_akhir'";

            $query_absensi_pulang = "SELECT tanggal, '' AS jam_datang, jam_pulang, '' AS keterangan, laporan, '' AS file, id_intern,
                                        '' AS status_datang,
                                        CASE WHEN jam_pulang = '' THEN '' 
                                             WHEN TIME(jam_pulang) < '17:00:00' THEN 'Pulang Lebih Awal' 
                                             WHEN TIME(jam_pulang) = '17:00:00' THEN 'Pulang Tepat Waktu' 
                                             ELSE 'Pulang Tepat Waktu' END AS status_pulang
                                        FROM absensi_pulang WHERE tanggal BETWEEN '$tanggal_awal' AND '$tanggal_akhir'";

            if ($mahasiswa_id !== 'all') {
                $query_absensi_datang .= " AND id_intern = '$mahasiswa_id'";
                $query_absensi_pulang .= " AND id_intern = '$mahasiswa_id'";
            }

            $query_rekap_absensi = "SELECT subquery.tanggal, 
                    CASE WHEN keterangan IN ('sakit', 'izin') THEN '' ELSE MAX(jam_datang) END AS jam_datang,  
                    CASE WHEN keterangan IN ('sakit', 'izin') THEN '' ELSE MAX(subquery.jam_pulang) END AS jam_pulang, 
                    MAX(subquery.keterangan) AS keterangan,
                    CASE WHEN keterangan IN ('sakit', 'izin') THEN '' ELSE MAX(subquery.laporan) END AS laporan,
                    MAX(subquery.file) AS file,
                    mahasiswaa.nama,
                    CASE 
                        WHEN MAX(subquery.keterangan) IN ('sakit', 'izin') THEN '' 
                        ELSE CONCAT_WS(' / ', 
                            CASE WHEN COALESCE(MAX(subquery.status_datang), '') = 'Datang Telat' THEN 'Datang Telat' ELSE 'Datang Tepat Waktu' END,
                            CASE WHEN COALESCE(MAX(subquery.jam_pulang), '') = '' THEN '' ELSE CASE WHEN COALESCE(MAX(subquery.status_pulang), '') = 'Pulang Lebih Awal' THEN 'Pulang Lebih Awal' ELSE 'Pulang Tepat Waktu' END END
                        ) 
                    END AS status,
                    subquery.id_intern
                    FROM (
                        $query_absensi_datang
                        UNION
                        $query_absensi_pulang
                    ) AS subquery
                    LEFT JOIN mahasiswaa ON subquery.id_intern = mahasiswaa.id_intern
                    GROUP BY subquery.tanggal, subquery.id_intern";

            $result_rekap_absensi = mysqli_query($con, $query_rekap_absensi);

            if($result_rekap_absensi){
                echo '<div class="table-container">';
                echo '<div class="table-responsive mt-6">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Jam Datang</th>
                                    <th>Jam Pulang</th>
                                    <th>Keterangan</th>
                                    <th>Laporan</th>
                                    <th>File</th>
                                    <th>Nama Mahasiswa</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>';
                while($row = mysqli_fetch_assoc($result_rekap_absensi)){
                    echo '<tr>';
                    echo '<td>' . $row['tanggal'] . '</td>';
                    echo '<td>' . $row['jam_datang'] . '</td>';
                    echo '<td>' . $row['jam_pulang'] . '</td>';
                    echo '<td>' . $row['keterangan'] . '</td>';
                    echo '<td>' . $row['laporan'] .'</td>';
                    
                    if($row['file'] != ''){
                        echo '<td><a href="../uploads/' . $row['file'] . '" target="_blank" style="text-decoration: none; color: black;"><i class="far fa-file-pdf fa-lg"></i></a></td>';
                    } else {
                        echo '<td>Tidak ada file</td>';
                    }
                    
                    echo '<td>' . $row['nama'] . '</td>';
                    echo '<td>' . $row['status'] . '</td>';
                    echo '<td><a href="rekap_presensi_detail.php?q=' . $row['id_intern'] . '" class="btn warna3">
                    <i class="fas fa-sliders"></i></a></td>';
                    echo '</tr>';
                }
                echo '</tbody></table></div> </div>';
                echo '<footer>
                        <div id="pagination" class="text-center">
                            <button class="pagination-btn" onclick="prevPage()">Previous</button>
                            <span class="pagination-info" id="page-info"></span>
                            <button class="pagination-btn" onclick="nextPage()">Next</button>
                        </div>
                      </footer>';
            } else {
                echo 'Gagal melihat rekap absensi' . mysqli_error($con);
            }
        }
        ?>

        <?php
        if(isset($tanggal_awal) && isset($tanggal_akhir)) {
            $query_total_absensi = "SELECT 
                                        m.nama, 
                                        MONTH(a.tanggal) AS bulan, 
                                        SUM(CASE WHEN a.keterangan IS NULL OR a.keterangan = 'hadir' THEN 1 ELSE 0 END) AS total_hadir,
                                        SUM(CASE WHEN a.keterangan = 'izin' THEN 1 ELSE 0 END) AS total_izin,
                                        SUM(CASE WHEN a.keterangan = 'sakit' THEN 1 ELSE 0 END) AS total_sakit
                                    FROM 
                                        absensi_datang a
                                    LEFT JOIN mahasiswaa m ON a.id_intern = m.id_intern
                                    WHERE a.tanggal BETWEEN '$tanggal_awal' AND '$tanggal_akhir'
                                    GROUP BY m.nama, MONTH(a.tanggal)";

            $result_total_absensi = mysqli_query($con, $query_total_absensi);

            if($result_total_absensi){
                echo '<div class="table-container">';
                echo '<div class="table-responsive mt-6">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Nama Mahasiswa</th>
                                    <th>Bulan</th>
                                    <th>Total Hadir</th>
                                    <th>Total Izin</th>
                                    <th>Total Sakit</th>
                                </tr>
                            </thead>
                            <tbody>';
                while($row = mysqli_fetch_assoc($result_total_absensi)){
                    echo '<tr>';
                    echo '<td>' . $row['nama'] . '</td>';
                    echo '<td>' . $row['bulan'] . '</td>';
                    echo '<td>' . $row['total_hadir'] . '</td>';
                    echo '<td>' . $row['total_izin'] . '</td>';
                    echo '<td>' . $row['total_sakit'] . '</td>';
                    echo '</tr>';
                }
                echo '</tbody></table></div> </div>';
            } else {
                echo 'Gagal menghitung total absensi' . mysqli_error($con);
            }
        }
        ?>
    </div>  
    <script>
        var itemsPerPage = 10;
        var totalRows = document.getElementsByTagName('tbody')[0].getElementsByTagName('tr').length;
        var totalPages = Math.ceil(totalRows / itemsPerPage);
        var currentPage = parseInt(sessionStorage.getItem('currentPage')) || 1;

        function createPagination() {
            var paginationHTML = '';

            if (currentPage > 1) {
                paginationHTML += '<button class="pagination-btn" onclick="prevPage()">Previous</button>';
            }

            paginationHTML += '<span class="pagination-info">Page ' + currentPage + ' of ' + totalPages + '</span>';

            if (currentPage < totalPages) {
                paginationHTML += '<button class="pagination-btn" onclick="nextPage()">Next</button>';
            }

            document.getElementById('pagination').innerHTML = paginationHTML;
            document.getElementById('page-info').innerHTML = 'Page ' + currentPage + ' of ' + totalPages;
        }

        function prevPage() {
            if (currentPage > 1) {
                currentPage--;
                showPage(currentPage);
                sessionStorage.setItem('currentPage', currentPage);
            }
        }

        function nextPage() {
            if (currentPage < totalPages) {
                currentPage++;
                showPage(currentPage);
                sessionStorage.setItem('currentPage', currentPage);
            }
        }

        function showPage(pageNumber) {
            var startIndex = (pageNumber - 1) * itemsPerPage;
            var endIndex = Math.min(startIndex + itemsPerPage, totalRows);
            var rows = document.getElementsByTagName('tbody')[0].getElementsByTagName('tr');

            for (var i = 0; i < rows.length; i++) {
                if (i >= startIndex && i < endIndex) {
                    rows[i].style.display = '';
                } else {
                    rows[i].style.display = 'none';
                }
            }

            totalPages = Math.ceil(totalRows / itemsPerPage);

            createPagination();
        }

        showPage(currentPage);
    </script>  
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>
