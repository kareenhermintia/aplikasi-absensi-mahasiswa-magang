<?php
    session_start();
    require "../koneksi.php";

    //database data_mahasiswa
    $query = mysqli_query($con, "SELECT * FROM mahasiswaa");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Mahasiswa || Admin</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <style>
        body {
            font-size: 20px;
            font-family: "Poppins", sans-serif; 
        }
        h4{
            font-size: 15px;
        }
    </style>
</head>
<body>
    <!----bagian sidebar--->
    <?php require "sidebar.php"; ?>
    <!---page content--->
    <div class="main" style="margin-left:350px; margin-top:90px;">
    <header class="container" style="padding-top:10px">
        <h5><b><i class="fas fa-user-edit"></i> Tambah Data Mahasiswa</b></h5>
    </header>

    <div class="my-5 col-12 col-md-6">
       <h4><b>Tambah Data Mahasiswa</b></h4>
       <form action="" method="post" enctype="multipart/form-data">
        <div>
            <label for="id_intern">Nomor Internship</label>
            <input type="text" id="id_intern" name="id_intern" class="form-control" required>
        </div>
        <div>
            <label for="nama">Nama Lengkap</label>
            <input type="text" id="nama" name="nama" class="form-control" required>
        </div>
        <div>
            <label for="jurusan">Jurusan</label>
            <input type="text" name="jurusan" id="jurusan" class="form-control" required>
        </div>
        <div>
            <label for="divisi">Divisi</label>
            <input type="text" id="divisi" name="divisi" class="form-control" required>
        </div>
        <div>
            <label for="universitas">Universitas</label>
            <input type="text" id="universitas" name="universitas" class="form-control" required>
        </div>
        <div>
            <label for="jenis_kelamin">Jenis Kelamin</label>
            <select name="jenis_kelamin" id="jenis_kelamin" class="form-control" required>
                <option selected>Pilih Jenis Kelamin</option>
                <option value="Laki_laki">Laki-laki</option>
                <option value="Perempuan">Perempuan</option>
            </select>
        </div>
        <div>
            <label for="alamat">Alamat</label>
            <textarea name="alamat" id="alamat" cols="10" rows="5" class="form-control"></textarea>
        </div>
        <div>
            <label for="no_telpon">No. Telp</label>
            <input type="number" name="no_telpon" id="no_telpon" class="form-control" required>
        </div>
        <div>
            <label for="username">Username</label>
            <input type="username" name="username" id="username" class="form-control" required>
        </div>
        <div class="mt-3">
        <button class="btn btn-primary" type="submit" name="input">Input</button>
       </div>
       </form>
       <?php
       if(isset($_POST['input'])){
        // Lakukan pemrosesan data di sini
        $id_intern = htmlspecialchars($_POST['id_intern']);
        $nama = htmlspecialchars($_POST['nama']);
        $jurusan = htmlspecialchars($_POST['jurusan']);
        $divisi = htmlspecialchars($_POST['divisi']);
        $universitas = htmlspecialchars($_POST['universitas']);
        $jenis_kelamin = htmlspecialchars($_POST['jenis_kelamin']);
        $alamat = htmlspecialchars($_POST['alamat']);
        $no_telpon = htmlspecialchars($_POST['no_telpon']);
        $username = htmlspecialchars($_POST['username']);

        // Pastikan nomor telepon dimulai dengan angka 0
        if (substr($no_telpon, 0, 1) != '0') {
            $no_telpon = '0' . $no_telpon;
        }
    
        // Periksa apakah nilai yang diambil dari form tidak kosong sebelum memasukkannya ke dalam database
        if (!empty($id_intern) && !empty($nama) && !empty($jurusan) && !empty($divisi) && !empty($universitas) && !empty($jenis_kelamin) && !empty($alamat) && !empty($no_telpon) && !empty($username)) {
        // Query insert data mahasiswa
        $queryTambah = mysqli_query($con, "INSERT INTO mahasiswaa (id_intern, nama, jurusan, divisi, universitas, jenis_kelamin, alamat, no_telpon, username) VALUES ('$id_intern', '$nama', '$jurusan', '$divisi', '$universitas', '$jenis_kelamin', '$alamat', '$no_telpon', '$username')");

        if($queryTambah){
            ?>
            <div class="alert alert-primary mt-3" role="alert">
                Data mahasiswa berhasil ditambahkan!
            </div>
            <!-- Refresh halaman -->
            <meta http-equiv="refresh" content="3; url=data_mahasiswa.php"/>
            <?php
        } else {
            // Tampilkan pesan kesalahan jika query gagal dieksekusi
            echo mysqli_error($con);
        }
    } else {
        // Tampilkan pesan kesalahan jika ada nilai yang kosong
        ?>
        <div class="alert alert-danger mt-3" role="alert">
            Mohon lengkapi semua kolom!
        </div>
        <?php
    }
}  
?>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>