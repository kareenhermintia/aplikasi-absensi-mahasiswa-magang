<?php
session_start();
require "../koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Akun</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <style>
        body {
            font-size: 20px;
            font-family: "Poppins", sans-serif;
            margin: 20px;
        }
        .table {
            text-align: center;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.20);
            font-size: 1.0rem;
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
        }
        .table th,
        .table td {
            vertical-align: middle;
            border: 1px solid #ddd;
            padding: 12px;
        }
        .table thead {
            background-color: #948979;
            color: white;
        }
        .table tbody tr:hover {
            background-color: #f5f5f5;
        }
        .table-responsive {
            overflow-x: auto;
        }
        .btn.warna3 {
            background-color: #948979;
            color: white;
        }
        .btn.warna3:hover {
            background-color: #746856;
        }
        .table-container {
            margin: 0 auto;
            width: 95%;
            display: block;
            padding-top: 5px;
        }
    </style>
</head>
<body>
    <!--sidebar content-->
    <?php require "sidebar.php"; ?>

    <!---page content--->
    <div class="main" style="margin-left:350px; margin-top:90px;">
        <header class="container" style="padding-top:10px">
            <h5><b><i class="fas fa-user-edit"></i> Tambah Data Akun</b></h5>
        </header>
        <div>
            <a class="btn btn-primary mt-3" href="register.php" role="button">Tambah Data Akun</a>
        </div>
    </div>
    <!---membuat table list--->
    <div class="mt-4 mb-5" style="margin-left:350px; margin-right:100px;">
        <h4><b>List Data Akun</b></h4>
        <div class="table-container">
            <div class="table-responsive mt-6">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Nama</th>
                            <th>Level</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Query untuk mendapatkan data dari tabel users
                        $query_users = "SELECT username, nama, level FROM users";
                        $result_users = mysqli_query($con, $query_users);

                        // Menampilkan data dalam tabel
                        while ($row_user = mysqli_fetch_assoc($result_users)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row_user['username']); ?></td>
                                <td><?php echo htmlspecialchars($row_user['nama']); ?></td>
                                <td><?php echo htmlspecialchars($row_user['level']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>
