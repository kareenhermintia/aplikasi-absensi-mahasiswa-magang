<?php
    session_start();
    require "../koneksi.php";

    $id_intern = $_GET['q'];

    //untuk database
    $query = mysqli_query($con, "SELECT * FROM mahasiswaa WHERE id_intern='$id_intern'");
    $data = mysqli_fetch_array($query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mahasiswa Detail || Admin</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
</head>
<style>
    body {
        font-size: 20px;
        font-family: "Poppins", sans-serif;
    }
    form div{
    margin-bottom: 10px;
    }
</style>
<body>
    <!---memanggil navbar--->
    <?php require "sidebar.php"; ?>
    <!---page content--->
    <div class="main" style="margin-left:350px; margin-top:90px;">
    <header class="container" style="padding-top:10px">
        <h5><b><i class="far fa-edit"></i></i> Edit Data Mahasiswa</b></h5>
    </header>

    <!---form data mahasiswa_detail--->
    <div class="my-5 col-12 col-md-6">
        <h4>Data Mahasiswa</h4>
        <form action="" method="post" enctype="multipart/form-data">
            <div>
                <label for="id_intern">Nomor Internship</label>
                <input type="text" id="id_intern" name="id_intern" class="form-control" value="<?php echo $data['id_intern']; ?>" required>
            </div>
            <div>
                <label for="nama">Nama</label>
                <input type="text" id="nama" name="nama" class="form-control" value="<?php echo $data['nama']; ?> " required>
            </div>
            <div>
                <label for="jurusan">Jurusan</label>
                <input type="text" id="jurusan" name="jurusan" class="form-control" value="<?php echo $data['jurusan']; ?>" required>
            </div>
            <div>
                <label for="divisi">Divisi</label>
                <input type="text" id="divisi" name="divisi" class="form-control" value="<?php echo $data['divisi']?>" required>
            </div>
            <div>
                <label for="universitas">Universitas</label>
                <input type="text" id="universitas" name="universitas" class="form-control" value="<?php echo $data['universitas']?>" required>
            </div>
            <div>
                <label for="jenis_kelamin">Jenis Kelamin</label>
                <select name="jenis_kelamin" id="jenis_kelamin" class="form-control" required>
                    <option selected>Pilih Jenis Kelamin</option>
                    <option value="Laki_laki" <?php if($data['jenis_kelamin'] == 'Laki_laki') echo 'selected'; ?>>Laki-Laki</option>
                    <option value="Perempuan" <?php if($data['jenis_kelamin'] == 'Perempuan') echo 'selected'; ?>>Perempuan</option>
                </select>
            </div>
            <div>
                <label for="alamat">Alamat</label>
                <textarea name="alamat" id="alamat" cols="10" rows="5" class="form-control"><?php echo $data['alamat']; ?></textarea>
            </div>
            <div>
                <label for="no_telpon">No. Telp</label>
                <input type="number" id="no_telpon" name="no_telpon" class="form-control" value="<?php echo $data['no_telpon']; ?>" required>
            </div>
            <div>
                <label for="username">Username</label>
                <input type="username" id="username" name="username" class="form-control" value="<?php echo $data['username']; ?>" required>
            </div>
            <div>
                <button type="submit" class="btn btn-primary" name="simpan">Update</button>
                <button type="submit" class="btn btn-danger" name="hapus">Delete</button>
            </div>
        </form>
    </div>    

    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
    <script>
        function showMessage(message, redirect = false) {
            alert(message);
            if (redirect) {
                window.location.href = 'data_mahasiswa.php';
            }
        }
    </script>
</body>
</html>

<?php
        if(isset($_POST['simpan'])){
            $id_intern = htmlspecialchars($_POST['id_intern']);
            $nama = htmlspecialchars($_POST['nama']);
            $jurusan = htmlspecialchars($_POST['jurusan']);
            $divisi = htmlspecialchars($_POST['divisi']);
            $universitas = htmlspecialchars($_POST['universitas']);
            $jenis_kelamin = htmlspecialchars($_POST['jenis_kelamin']);
            $alamat = htmlspecialchars($_POST['alamat']);
            $no_telpon = htmlspecialchars($_POST['no_telpon']);
            $username = htmlspecialchars($_POST['username']);

            if(substr($no_telpon, 0, 1) != '0'){
                $no_telpon = '0' . $no_telpon;
            }

            //memeriksa nilai yang diambil dari form tidak kosong
            if(!empty($id_intern) && !empty($nama) && !empty($jurusan) && !empty($divisi) && !empty($universitas) && !empty($jenis_kelamin) && !empty($alamat) && !empty($no_telpon) && !empty($username)){

                //query update
                $queryUpdate = mysqli_query($con, "UPDATE mahasiswaa SET nama='$nama', jurusan='$jurusan', divisi='$divisi', universitas='$universitas', jenis_kelamin='$jenis_kelamin', alamat='$alamat', no_telpon='$no_telpon', username='$username' WHERE id_intern='$id_intern'");
                
                if($queryUpdate){
                    echo "<script>showMessage('Data mahasiswa berhasil di update!', true);</script>";
                } else {
                    echo "<script>showMessage('Gagal memperbarui data mahasiswa: " . mysqli_error($con) . "');</script>";
                }
            }
        }

        if(isset($_POST['hapus'])){
            $queryHapus = mysqli_query($con, "DELETE FROM mahasiswaa WHERE id_intern='$id_intern'");

            if($queryHapus){
                echo "<script>showMessage('Data mahasiswa berhasil dihapus!', true);</script>";
            } else {
                echo "<script>showMessage('Gagal menghapus data mahasiswa: " . mysqli_error($con) . "');</script>";
            }        
        }
?>
