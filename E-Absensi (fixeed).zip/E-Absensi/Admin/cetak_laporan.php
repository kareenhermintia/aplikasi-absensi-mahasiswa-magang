<?php
session_start();
require "../koneksi.php";

// Pastikan ada sesi yang aktif
if (!isset($_SESSION['id_user'])) {
    header("Location: login.php"); // Redirect ke halaman login jika tidak ada sesi yang aktif
    exit();
}

// Ambil id_user dari sesi admin
$id_user = $_SESSION['id_user'];

// Variabel untuk menyimpan pesan kesalahan
$error_message = "";

// Jika ada permintaan untuk melihat laporan absensi mahasiswa tertentu
if (isset($_GET['id_intern']) && isset($_GET['bulan'])) {
    $mahasiswa_id = $_GET['id_intern'];
    $bulan = $_GET['bulan'];

    // Query untuk mengambil data mahasiswa berdasarkan id_user dan bulan yang dipilih
    $query = "SELECT m.nama, m.divisi, m.jurusan, m.no_telpon, ad.tanggal, ad.jam_datang, ad.keterangan, ap.jam_pulang, ap.laporan 
              FROM mahasiswaa m
              LEFT JOIN absensi_datang ad ON m.id_intern = ad.id_intern
              LEFT JOIN absensi_pulang ap ON m.id_intern = ap.id_intern AND ad.tanggal = ap.tanggal
              WHERE m.id_intern = '$mahasiswa_id' AND MONTH(ad.tanggal) = '$bulan'
              ORDER BY ad.tanggal";
    $result = mysqli_query($con, $query);

    // Periksa apakah query berhasil dieksekusi
    if ($result && mysqli_num_rows($result) > 0) {
        // Data mahasiswa ditemukan, tampilkan laporan absensinya
        $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
    } else {
        $error_message = "Data mahasiswa tidak ditemukan atau tidak ada absensi untuk bulan yang dipilih.";
    }
}

// Query untuk mengambil daftar mahasiswa
$query_mahasiswa = "SELECT id_intern, nama FROM mahasiswaa";
$result_mahasiswa = mysqli_query($con, $query_mahasiswa);

// Periksa apakah query berhasil dieksekusi
if (!$result_mahasiswa) {
    die("Kesalahan: " . mysqli_error($con));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Laporan Absensi</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../fontawesome/fontawesome.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <style>
        body {
            font-size: 20px;
            font-family: "Poppins", sans-serif;
        }
        .navbar {
            background-color: #E4C59E;
            padding: 10px 10px;
            position: fixed;
            top: 0;
            width: 100%;
            font-weight: bold;
        }
        .p .navbar-brand {
            padding: 10px 20px;
            font-size: 24px;
            margin-right: 10px;
        }
        .tb_head {
            margin: auto;
            padding: 5px;
            font-size: 20px;
            text-align: left;
        }
        .container {
            margin-top: 90px;
        }
        .card {
            width: 100%;
            max-width: 800px;
            margin: auto;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }
        .tb_data {
            border-collapse: collapse;
            width: 100%;
            font-size: 15px;
        }
        .tb_data th, .tb_data td {
            border: 1px solid black;
            padding: 8px;
            text-align: center;
        }
        .judul {
            font-size: 20px;
            margin-top: 10px;
            text-align: center;
            font-weight: bold;
        }
        .error-message {
            color: red;
            text-align: center;
            margin-top: 20px;
            font-size: 18px;
        }
        @media print {
            body {
                font-size: 10px;
            }
            .tb_head th, 
            .tb_head td { 
                font-size: 12px;
            }
            .tb_data th,
            .tb_data td {
                font-size: 10px;
            }
            .no-print {
                display: none;
            }
        }
        @page {
            margin: 0;
            size: auto;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg no-print">
        <div class="container-fluid">
            <p class="navbar-brand">Cetak Laporan Absensi</p>
            <div class="button-group">
                <a class="btn btn-primary" href="rekap_presensi.php" role="button">Kembali</a>
                <button id="btnPrint" type="button" class="btn btn-secondary active" aria-pressed="true">Cetak</button>
            </div>
        </div>
    </nav>
    <div class="container">
        <div class="card no-print">
        <form action="" method="GET" class="no-print">
            <div class="mb-3">
                <label for="id_intern" class="form-label"><b>Pilih Mahasiswa:</b></label>
                <select class="form-select" name="id_intern" id="id_intern">
                    <?php while ($row_mahasiswa = mysqli_fetch_assoc($result_mahasiswa)): ?>
                        <option value="<?php echo $row_mahasiswa['id_intern']; ?>"><?php echo $row_mahasiswa['nama']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="bulan" class="form-label"><b>Pilih Bulan:</b></label>
                <select class="form-select" name="bulan" id="bulan">
                    <option value="1">Januari</option>
                    <option value="2">Februari</option>
                    <option value="3">Maret</option>
                    <option value="4">April</option>
                    <option value="5">Mei</option>
                    <option value="6">Juni</option>
                    <option value="7">Juli</option>
                    <option value="8">Agustus</option>
                    <option value="9">September</option>
                    <option value="10">Oktober</option>
                    <option value="11">November</option>
                    <option value="12">Desember</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Pilih</button>
        </form>
        </div>
        <br>
        <?php if (isset($rows)): ?>
            <h2 class="judul"><u>Laporan Absensi Mahasiswa Magang</u></h2>
            <br>
            <table class="tb_head" width="100%">
            <tbody>
                <tr>
                    <td>Nama</td>
                    <td><?php echo $rows[0]['nama']; ?></td>
                    <td>Divisi</td>
                    <td><?php echo $rows[0]['divisi']; ?></td>
                </tr>
                <tr>
                    <td>Jurusan</td>
                    <td><?php echo $rows[0]['jurusan']; ?></td>
                    <td>Nomer Telpon</td>
                    <td><?php echo $rows[0]['no_telpon']; ?></td>
                </tr>
            </tbody>
        </table>
        <br>
            <table class="tb_data">
                <thead>
                    <tr>
                        <th scope="col">Tanggal</th>
                        <th scope="col">Jam Datang</th>
                        <th scope="col">Jam Pulang</th>
                        <th scope="col">Keterangan</th>
                        <th scope="col">Laporan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rows as $row): ?>
                        <tr>
                            <td><?php echo $row['tanggal']; ?></td>
                            <td><?php echo ($row['keterangan'] == 'Izin' || $row['keterangan'] == 'Sakit') ? '' : $row['jam_datang']; ?></td>
                            <td><?php echo ($row['keterangan'] == 'Izin' || $row['keterangan'] == 'Sakit') ? '' : $row['jam_pulang']; ?></td>
                            <td><?php echo $row['keterangan']; ?></td>
                            <td><?php echo $row['laporan']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php elseif ($error_message): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>
    </div>

    <script>
        var btnPrint = document.getElementById('btnPrint');
        btnPrint.addEventListener('click', function() {
            window.print();
        });
    </script>
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../fontawesome/js/all.min.js"></script>
</body>
</html>
