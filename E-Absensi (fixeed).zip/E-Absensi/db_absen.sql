-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 20, 2024 at 10:36 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_absen`
--

-- --------------------------------------------------------

--
-- Table structure for table `absensi_datang`
--

CREATE TABLE `absensi_datang` (
  `id_absen` int(11) NOT NULL,
  `id_intern` varchar(30) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `jam_datang` time DEFAULT NULL,
  `keterangan` enum('Hadir','Izin','Sakit') DEFAULT NULL,
  `file` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `absensi_datang`
--

INSERT INTO `absensi_datang` (`id_absen`, `id_intern`, `tanggal`, `jam_datang`, `keterangan`, `file`) VALUES
(23, 'Intern-001', '2024-05-06', '08:08:28', 'Hadir', NULL),
(24, 'Intern-002', '2024-05-06', '08:12:32', 'Hadir', NULL),
(25, 'Intern-003', '2024-05-06', '08:12:32', 'Hadir', NULL),
(26, 'Intern-001', '2024-05-07', '08:00:50', 'Hadir', NULL),
(27, 'Intern-003', '2024-05-07', '08:00:32', 'Hadir', NULL),
(28, 'Intern-002', '2024-05-07', '08:02:00', 'Hadir', NULL),
(29, 'Intern-001', '2024-05-08', '08:00:00', 'Hadir', NULL),
(30, 'Intern-002', '2024-05-08', '08:02:00', 'Hadir', NULL),
(31, 'Intern-003', '2024-05-08', '08:00:00', 'Hadir', NULL),
(32, 'Intern-001', '2024-05-13', '08:00:00', 'Hadir', NULL),
(33, 'Intern-002', '2024-05-13', '08:00:00', 'Hadir', NULL),
(34, 'Intern-003', '2024-05-13', '08:00:00', 'Hadir', NULL),
(35, 'Intern-002', '2024-05-13', '08:00:00', 'Hadir', NULL),
(36, 'Intern-001', '2024-05-14', '08:00:00', 'Hadir', NULL),
(37, 'Intern-002', '2024-05-14', '08:00:00', 'Hadir', NULL),
(38, 'Intern-001', '2024-05-15', '08:00:00', 'Hadir', NULL),
(39, 'Intern-002', '2024-05-15', '08:00:00', 'Hadir', NULL),
(40, 'Intern-003', '2024-05-15', '08:00:00', 'Hadir', NULL),
(43, 'Intern-002', '2024-05-16', '08:02:00', 'Hadir', NULL),
(44, 'Intern-003', '2024-05-16', '08:09:00', 'Izin', 'surat izin kartika.pdf'),
(45, 'Intern-001', '2024-05-16', '08:10:00', 'Izin', 'surat izin kareen.pdf'),
(46, 'Intern-001', '2024-05-22', '09:35:00', 'Hadir', NULL),
(47, 'Intern-001', '2024-05-27', '09:53:00', 'Hadir', NULL),
(48, 'Intern-002', '2024-05-27', '10:20:00', 'Hadir', NULL),
(49, 'Intern-003', '2024-05-27', '10:27:00', 'Hadir', NULL),
(56, 'Intern-002', '2024-06-03', '09:52:00', 'Hadir', NULL),
(57, 'Intern-003', '2024-06-03', '09:55:00', 'Hadir', NULL),
(63, 'Intern-001', '2024-06-03', '08:09:00', 'Hadir', ''),
(64, 'Intern-001', '2024-06-04', '08:00:00', 'Hadir', NULL),
(65, 'Intern-002', '2024-06-04', '08:00:00', 'Hadir', NULL),
(66, 'Intern-003', '2024-06-04', '08:12:32', 'Hadir', NULL),
(67, 'Intern-001', '2024-06-05', '08:02:00', 'Hadir', NULL),
(68, 'Intern-002', '2024-06-05', '08:00:00', 'Hadir', NULL),
(69, 'Intern-003', '2024-06-05', '08:00:00', 'Hadir', NULL),
(73, 'Intern-001', '2024-06-06', '08:00:00', 'Hadir', NULL),
(74, 'Intern-002', '2024-06-06', '08:00:00', 'Hadir', NULL),
(75, 'Intern-003', '2024-06-06', '08:02:00', 'Hadir', NULL),
(76, 'Intern-001', '2024-06-07', '08:00:00', 'Hadir', NULL),
(77, 'Intern-002', '2024-06-07', '08:00:00', 'Hadir', NULL),
(78, 'Intern-003', '2024-06-07', '08:00:00', 'Hadir', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `absensi_pulang`
--

CREATE TABLE `absensi_pulang` (
  `id_absensi` int(11) NOT NULL,
  `id_intern` varchar(30) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `jam_pulang` time DEFAULT NULL,
  `laporan` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `absensi_pulang`
--

INSERT INTO `absensi_pulang` (`id_absensi`, `id_intern`, `tanggal`, `jam_pulang`, `laporan`) VALUES
(11, 'Intern-001', '2024-05-06', '17:05:41', 'Membuat codingan logger'),
(12, 'Intern-002', '2024-05-06', '17:05:41', 'Membuat logger di java'),
(13, 'Intern-003', '2024-05-06', '17:13:38', 'Membuat desain id-card karyawan'),
(14, 'Intern-001', '2024-05-07', '17:02:41', 'Membuat parameter cogs simpro'),
(15, 'Intern-002', '2024-05-07', '17:13:38', 'Membuat parameter costaccount'),
(16, 'Intern-003', '2024-05-07', '17:06:49', 'Membuat desain hari perayaan'),
(17, 'Intern-001', '2024-05-08', '17:05:41', 'Membuat parameter project simpro'),
(18, 'Intern-002', '2024-05-08', '17:15:38', 'Membuat parameter project simpro'),
(19, 'Intern-003', '2024-05-08', '17:02:41', 'Membantu laporan RSF untuk tim presales'),
(20, 'Intern-001', '2024-05-13', '17:02:41', 'Mengganti codingan logger'),
(21, 'Intern-002', '2024-05-13', '17:07:38', 'Mengganti codingan logger'),
(22, 'Intern-003', '2024-05-13', '17:02:41', 'Membuat desain poster'),
(23, 'Intern-001', '2024-05-14', '17:07:00', 'Melanjutkan parameter project simpro'),
(24, 'Intern-002', '2024-05-14', '17:02:41', 'Melanjutkan project simpro'),
(26, 'Intern-001', '2024-05-15', '17:02:41', 'Mengganti codingan logger'),
(27, 'Intern-002', '2024-05-15', '17:07:38', 'Mengganti codingan logger'),
(28, 'Intern-003', '2024-05-15', '17:05:38', 'Membuat desain UI'),
(29, 'Intern-002', '2024-05-16', '17:37:00', 'Membuat parameter project simpro'),
(30, 'Intern-001', '2024-05-27', '17:03:00', 'Membuat parameter untuk simpro'),
(31, 'Intern-002', '2024-05-27', '17:15:33', 'Melanjutkan project simpro'),
(32, 'Intern-003', '2024-05-27', '17:13:38', 'Membuat desain poster'),
(33, 'Intern-001', '2024-05-22', '17:05:41', 'Membuat Parameter untuk simpro'),
(34, 'Intern-001', '2024-06-03', '17:11:00', 'Melanjutkan codingan simpro'),
(35, 'Intern-002', '2024-06-03', '17:06:49', 'Melanjutkan project simpro'),
(36, 'Intern-003', '2024-06-03', '17:06:49', 'Membuat desain Id-card'),
(37, 'Intern-001', '2024-06-04', '17:02:41', 'Mengganti dokumentasi CPR di excel'),
(38, 'Intern-002', '2024-06-04', '17:07:38', 'Melanjutkan project simpro'),
(39, 'Intern-003', '2024-06-04', '17:02:41', 'Mengedit dokumen RSF Presales'),
(40, 'Intern-001', '2024-06-05', '17:02:41', 'Merevisi dokumentasi CPR di excel'),
(41, 'Intern-002', '2024-06-05', '17:07:38', 'Membuat code parameter untuk simpro'),
(42, 'Intern-003', '2024-06-05', '17:05:41', 'Membuat desain logo CPR'),
(43, 'Intern-001', '2024-06-06', '17:07:00', 'Melanjutkan project simpro'),
(44, 'Intern-002', '2024-06-06', '17:07:38', 'Melanjutkan project simpro'),
(45, 'Intern-003', '2024-06-06', '17:02:41', 'Merevisi desain logo CPR'),
(46, 'Intern-001', '2024-06-07', '17:13:38', 'Mengganti codingan logger di ecms bsi'),
(47, 'Intern-002', '2024-06-07', '17:15:33', 'Mengganti codingan logger di ecms bsi'),
(48, 'Intern-003', '2024-06-07', '17:07:38', 'Membuat desain id card');

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswaa`
--

CREATE TABLE `mahasiswaa` (
  `id_user` int(11) NOT NULL,
  `id_intern` varchar(30) DEFAULT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `jurusan` varchar(50) DEFAULT NULL,
  `divisi` varchar(50) DEFAULT NULL,
  `universitas` varchar(100) DEFAULT NULL,
  `jenis_kelamin` varchar(10) DEFAULT NULL,
  `alamat` varchar(255) DEFAULT NULL,
  `no_telpon` varchar(15) DEFAULT NULL,
  `username` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mahasiswaa`
--

INSERT INTO `mahasiswaa` (`id_user`, `id_intern`, `nama`, `jurusan`, `divisi`, `universitas`, `jenis_kelamin`, `alamat`, `no_telpon`, `username`) VALUES
(18, 'Intern-001', 'Kareen Hermintia Kahar      ', 'Teknologi Informasi', 'SWD', 'Universitas Darma Persada', 'Perempuan', 'Jalan Sawo Kecik 1', '081997957355', 'kareenhermintia19@gmail.com'),
(19, 'Intern-002', 'Fanny Kusuma ', 'Teknik Informatika', 'SWD', 'President University', 'Perempuan', 'Perumahan Regency Tambun Utara', '087775260870', 'fannykusuma@gmail.com'),
(20, 'Intern-003', 'Kartika', 'Sosiologi', 'PMD', 'Universitas Negeri Jakarta', 'Perempuan', 'Jalan U Kebon Baru', '085714001534', 'kartika@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id_user` int(50) NOT NULL,
  `id_intern` varchar(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` enum('Mahasiswa','Admin') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id_user`, `id_intern`, `username`, `nama`, `password`, `level`) VALUES
(1, 'Intern-001', 'kareenhermintia19@gmail.com', 'Kareen Hermintia Kahar', '$2y$10$1w.ytpCWlVGqBRn41w0X6.WC3rbF6YyVnd/19UCsZpq47BImfYueC', 'Mahasiswa'),
(2, '', 'admin@gmail.com', 'admin', '$1$Pnn0M72a$Gd.hohxUMIOJcNMyFxdwa/', 'Admin'),
(13, 'Intern-002', 'fannykusuma@gmail.com', 'Fanny Kusuma', '$2y$10$U9cpjRpqInhAQ0uqg.AD6e9QRs/jIHP9Hu6xtqaeWczMZEiEYxxoe', 'Mahasiswa'),
(18, 'Intern-003', 'kartika@gmail.com', 'Kartika', '$2y$10$2RuzwjZilOgyLUE7KrhIdOQhn4lRb0zjtrmXsCtzAUnjN9/MbvDXm', 'Mahasiswa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absensi_datang`
--
ALTER TABLE `absensi_datang`
  ADD PRIMARY KEY (`id_absen`);

--
-- Indexes for table `absensi_pulang`
--
ALTER TABLE `absensi_pulang`
  ADD PRIMARY KEY (`id_absensi`);

--
-- Indexes for table `mahasiswaa`
--
ALTER TABLE `mahasiswaa`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD KEY `id_intern` (`id_intern`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absensi_datang`
--
ALTER TABLE `absensi_datang`
  MODIFY `id_absen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `absensi_pulang`
--
ALTER TABLE `absensi_pulang`
  MODIFY `id_absensi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `mahasiswaa`
--
ALTER TABLE `mahasiswaa`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
