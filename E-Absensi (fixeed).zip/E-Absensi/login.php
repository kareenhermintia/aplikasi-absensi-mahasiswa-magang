<?php
session_start();
require "koneksi.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">
    <title>Login</title>
</head>
<style>
    body {
    font-family: Poppins;
    background-image: linear-gradient(rgba(255, 255, 255, 0.5), rgba(255, 255, 255, 0.5)), url('img/absensi.jpg'); /* Ganti 'path/to/your/image.jpg' dengan path menuju gambar Anda */
    background-size: cover;
    background-repeat: no-repeat;
    background-attachment: fixed;
    }
    .main{
        height: 100vh;
    }
    .login-box {
    width: 400px;
    height: 400px;
    box-sizing: border-box;
    border-radius: 10px;
    background-color: white; /* Tambahkan warna latar belakang yang solid */
    padding: 20px; /* Atur padding agar isi konten tidak berada terlalu dekat dengan tepi */
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1); /* Tambahkan bayangan menggunakan box-shadow */
    }
    .warna1 {
        background-color: #898121;
    }
    .warna2 {
        background-color: #e7b10a;
    }
    .warna3 {
        background-color: #898121;
    }
    .warna4 {
        background-color: #862b0d;
    }
    .no-decoration {
        text-decoration: none;
        margin: 0 auto;
        display: block;
        text-align: center;
    }
    a {
        color: black;
    }
</style>
<body>
    <div class="main d-flex flex-column justify-content-center align-items-center">
        <div class="login-box p-5 shadow">
            <h3 class="text-center">Login</h3>
            <form action="" method="post">
                <div class="mb-3">
                    <label for="email">Username</label>
                    <input type="email" class="form-control" name="email" id="email" value="">
                </div>
                <div class="mb-3">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" id="password" value="">
                </div>
                <div class="mb-3">
                    <select class="form-select" aria-label="Default select example" name="level" id="level">
                        <option selected>Pilih login sebagai</option>
                        <option value="Mahasiswa">Mahasiswa</option>
                        <option value="Admin">Admin</option>
                    </select>
                </div>
                <div>
                    <button class="btn warna2 form-control mt-3" type="submit" name="loginbtn">Login</button>
                </div>
            </form>
        </div>
        <div class="mt-3" style="width: 500px">
            <?php
            if(isset($_POST['loginbtn'])){
                $email = htmlspecialchars($_POST['email']);
                $password = htmlspecialchars($_POST['password']);
                $level = $_POST['level'];

                $query = mysqli_query($con, "SELECT * FROM users WHERE username='$email'");
                $countdata = mysqli_num_rows($query);
                $data = mysqli_fetch_array($query);

                //untuk admin
                //username : admin@gmail.com
                //password : haloadmin

                //untuk mahasiswa
                //username : mahasiswa
                //password : halomahasiswa

                if($countdata > 0){
                    if(password_verify($password, $data['password'])){
                        $_SESSION['username'] = $data['username'];
                        $_SESSION['login'] = true;
                        $_SESSION['id_user'] = $data['id_user'];
                        $_SESSION['id_intern'] = $data['id_intern'];
                        $_SESSION['nama'] = $data['nama'];
                        
                        //2 multi login
                        if($level == "Mahasiswa") {
                            header('location: mahasiswa/mahasiswa_index.php');
                        } elseif ($level == "Admin") {
                            header('location: admin/index.php');
                        }
                    }
                    else {
                        ?>
                        <div class="alert alert-warning" role="alert">
                            Password salah!
                        </div>
                        <meta http-equiv="refresh" content="2; url=login.php">
                        <?php
                    }
                }
                else {
                    ?>
                    <div class="alert alert-warning" role="alert">
                        Tidak dapat login, coba lagi!
                    </div>
                    <meta http-equiv="refresh" content="2; url=login.php">
                    <?php
                }
            }
            ?>
        </div>
    </div>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>
